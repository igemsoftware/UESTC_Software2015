//
//  AnotherViewController.h
//  FlipDemo
//
//  Created by kimjunhyuk on 12/7/14.
//  Copyright (c) 2015 Kimjunhyuk. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SoundManager.h"


@interface optionview : UIViewController
{
     UISlider *slider;
     UISlider *slider1;
}


@property (nonatomic, retain) IBOutlet UIButton *switchTrackButton;
@property (nonatomic, assign) NSUInteger trackIndex;


- (IBAction)playPauseMusic:(UIButton *)sender;
- (IBAction)switchTrack:(UIButton *)sender;
- (IBAction)setSoundVolume:(UISlider *)sender;
- (IBAction)setMusicVolume:(UISlider *)sender;


@end
