//
//  DazFireController.h
//  Dazzle
//
//  Created by Kimjunhyuk on 9/Aug/15.
//  Copyright (c) 2012 Leonhard Lichtschlag. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CAEmitterLayer;

// ===============================================================================================================
@interface DazFireController : UIViewController
// ===============================================================================================================

@property (strong) CAEmitterLayer *fireEmitter;
@property (strong) CAEmitterLayer *smokeEmitter;
@property (strong) CAEmitterLayer *thunderEmitter;

- (void) controlFireHeight:(id)sender;
- (void) setFireAmount:(float)zeroToOne;


@end
