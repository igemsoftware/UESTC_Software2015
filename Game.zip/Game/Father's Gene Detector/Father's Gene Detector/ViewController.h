//
//  ViewController.h
//  Father's Gene Detector
//
//  Created by Bruce on 9/11/15.
//  Copyright (c) 2015 Bruce. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SoundManager.h"
#import "AppDelegate.h"
#import "EAIntroView.h"





@class CAEmitterLayer;
@interface ViewController : UIViewController
{
    int state[10];
    
    int plus1,k;
    
    int stateview[5];
    
    UIButton *dna1;
    UIButton *dna2;
    UIButton *dna3;
    UIButton *dna4;
    UIButton *dna5;
    UIButton *dna6;
    UIButton *dna7;
    UIButton *dna8;
    UIButton *dna9;
    UIButton *dna10;
    
    UIButton *daddy;
    UIButton *circle11;
    UIButton *circle21;
    UIButton *circle31;
    UIButton *circle41;
    
    UIButton *circle10;
    UIButton *circle20;
    UIButton *circle30;
    UIButton *circle40;
    
    UIImageView *background2;
    
    UIButton *bsubmit;
    
    
}






@property (nonatomic, strong) NSTimer *paintingTimer;



@property (strong) CAEmitterLayer *thunderEmitter;
@property (strong) CAEmitterLayer *fireEmitter;
@property (strong) CAEmitterLayer *smokeEmitter;

//- (void) controlFireHeight:(id)sender;
- (void) setFireAmount:(float)zeroToOne;


@end

