//
//  AnotherViewController.m
//  FlipDemo
//
//  Created by kimjunhyuk on 12/7/14.
//  Copyright (c) 2015 Kimjunhyuk. All rights reserved.
//

#import "AnotherViewController1.h"
#import "optionview.h"
#import "MRFlipTransition.h"
#import "AppDelegate.h"

@interface optionview ()
{

}

@end

@implementation optionview

@synthesize switchTrackButton;
@synthesize trackIndex;

- (void)viewDidLoad
{
    [super viewDidLoad];
     self.view.backgroundColor =  [UIColor colorWithPatternImage: [UIImage imageNamed:@"shadow.png"]];

    slider = [[UISlider alloc]initWithFrame:CGRectMake(230, 90, 130, 80)];
    [slider addTarget:self action:@selector(setMusicVolume:) forControlEvents:UIControlEventValueChanged];
    slider.value = 90;
    [self.view addSubview:slider];
    
    slider1 = [[UISlider alloc]initWithFrame:CGRectMake(230, 150, 130, 80)];
    [slider1 addTarget:self action:@selector(setSoundVolume:) forControlEvents:UIControlEventValueChanged];
    slider1.value = 90;
    [self.view addSubview:slider1];

    
    
    UIImageView *bihen = [[UIImageView alloc] initWithFrame:CGRectMake(0,90,200,80)];
    [bihen setImage:[UIImage imageNamed:@"bihen.png"]];
    [self.view addSubview:bihen];
    
    UIImageView *mvol = [[UIImageView alloc] initWithFrame:CGRectMake(40, 100, 180, 43)];
    [mvol setImage:[UIImage imageNamed:@"mvol.png"]];
    [self.view addSubview:mvol];
    
    
    UIImageView *bihen1 = [[UIImageView alloc] initWithFrame:CGRectMake(0,150,200,80)];
    [bihen1 setImage:[UIImage imageNamed:@"bihen.png"]];
    [self.view addSubview:bihen1];
    
    UIImageView *svol = [[UIImageView alloc] initWithFrame:CGRectMake(40, 160, 180, 43)];
    [svol setImage:[UIImage imageNamed:@"svol.png"]];
    [self.view addSubview:svol];
    
    
    UIImageView *bihen2 = [[UIImageView alloc] initWithFrame:CGRectMake(0,220,280,80)];
    [bihen2 setImage:[UIImage imageNamed:@"bihen.png"]];
    [self.view addSubview:bihen2];
    
    
    UIButton *mon = [[UIButton alloc] initWithFrame:CGRectMake(80, 230, 230, 43)];
    [mon addTarget:self action:@selector(playPauseMusic:) forControlEvents:UIControlEventTouchUpInside];
    [mon setBackgroundImage:[UIImage imageNamed:@"mon"] forState:UIControlStateNormal];
    //[option setBackgroundImage:[UIImage imageNamed:@"option"] forState:UIControlStateHighlighted];
    [self.view addSubview:mon];
    
    
    
    /*UIButton *dna = [[UIButton alloc] initWithFrame:CGRectMake(60, 500, 210, 60)];
    [dna addTarget:self action:@selector(flyAway:) forControlEvents:UIControlEventTouchUpInside];
    [dna setBackgroundImage:[UIImage imageNamed:@"dna"] forState:UIControlStateNormal];
    [self.view addSubview:dna];*/
   
    
    UIImageView *bihen3 = [[UIImageView alloc] initWithFrame:CGRectMake(0,300,280,80)];
    [bihen3 setImage:[UIImage imageNamed:@"bihen.png"]];
    [self.view addSubview:bihen3];
    
    UIButton *trackswitch = [[UIButton alloc] initWithFrame:CGRectMake(80, 310, 200, 43)];
    [trackswitch addTarget:self action:@selector(switchTrack:) forControlEvents:UIControlEventTouchUpInside];
    [trackswitch setBackgroundImage:[UIImage imageNamed:@"musicswitch"] forState:UIControlStateNormal];
    [self.view addSubview:trackswitch];
    
    
    UIButton *back = [[UIButton alloc] initWithFrame:CGRectMake(80, 550, 230, 43)];
    [back addTarget:self action:@selector(flyAway:) forControlEvents:UIControlEventTouchUpInside];
    [back setBackgroundImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [self.view addSubview:back];
    
    
    
    [AppDelegate storyBoradAutoLay:self.view];
    

    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [(MRFlipTransition *)self.transitioningDelegate updateContentSnapshot:self.view afterScreenUpdate:YES];
}

- (void)flyAway:(id)sender

{
    
    
     [[SoundManager sharedManager] playSound:@"buttontouch.mp3" looping:NO];
    [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
}





- (void)playMusic
{
    if (trackIndex == 0)
    {
        [[SoundManager sharedManager] playMusic:@"梅花三弄.mp3" looping:YES];
    }
    else
    {
        [[SoundManager sharedManager] playMusic:@"pipa.mp3" looping:YES];
    }
}

- (IBAction)playPauseMusic:(UIButton *)sender
{
    
     [[SoundManager sharedManager] playSound:@"buttontouch.mp3" looping:NO];
    
    if ([SoundManager sharedManager].playingMusic)
    {
        [[SoundManager sharedManager] stopMusic];
        [sender setBackgroundImage:[UIImage imageNamed:@"moff"] forState:UIControlStateNormal];
        switchTrackButton.enabled = NO;
        switchTrackButton.alpha = 0.5;
    }
    else
    {
        [self playMusic];
        [sender setBackgroundImage:[UIImage imageNamed:@"mon"] forState:UIControlStateNormal];
        switchTrackButton.enabled = YES;
        switchTrackButton.alpha = 1.0;
    }
}

- (IBAction)switchTrack:(__unused UIButton *)sender
{
    [[SoundManager sharedManager] playSound:@"buttontouch.mp3" looping:NO];
    trackIndex ++;
    trackIndex = trackIndex % 2;
    [self playMusic];
}

- (IBAction)setSoundVolume:(UISlider *)sender
{
    [SoundManager sharedManager].soundVolume = sender.value;
}

- (IBAction)setMusicVolume:(UISlider *)sender
{
    [SoundManager sharedManager].musicVolume = sender.value;
}

/////////////////







@end
