//
//  AnotherViewController.m
//  FlipDemo
//
//  Created by kimjunhyuk on 12/7/14.
//  Copyright (c) 2015 Kimjunhyuk. All rights reserved.
//

#import "AnotherViewController1.h"
#import "optionview.h"
#import "MRFlipTransition.h"
#import "ViewController.h"
#import "CUSFlashLabel.h"
#import "AppDelegate.h"

@interface AnotherViewController1 ()

@end

@implementation AnotherViewController1

- (void)viewDidLoad
{
    [super viewDidLoad];

    
    
    self.view.backgroundColor =  [UIColor colorWithPatternImage: [UIImage imageNamed:@"shadow.png"]];
    
    
    son1 = [[UIButton alloc] initWithFrame:CGRectMake(75,176,270,250)];
    [son1 addTarget:self action:@selector(bodytouch:) forControlEvents:UIControlEventTouchUpInside];
    [son1 setBackgroundImage:[UIImage imageNamed:@"son2_on"] forState:UIControlStateNormal];
    son1.alpha = 0;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:5];
    son1.alpha = 0.7;
    [UIView commitAnimations];
    [self.view addSubview:son1];
    
    
    label = [[CUSFlashLabel alloc]initWithFrame:CGRectMake(110, 546, 300, 80)];
    [label setText:@"Click the body to"];
    [label setFont:[UIFont fontWithName:@"papyrus"  size:20]];
    [label setContentMode:UIViewContentModeTop];
    [label startAnimating];
    [self.view addSubview:label];
    
    label2 = [[CUSFlashLabel alloc]initWithFrame:CGRectMake(120, 576, 300, 80)];
    [label2 setText:@"check the gene"];
    [label2 setFont:[UIFont fontWithName:@"papyrus"  size:20]];
    [label2 setContentMode:UIViewContentModeTop];
    [label2 startAnimating];
    [self.view addSubview:label2];

    
    [AppDelegate storyBoradAutoLay:self.view];
    

    

   
 
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [(MRFlipTransition *)self.transitioningDelegate updateContentSnapshot:self.view afterScreenUpdate:YES];
    

}

- (void)flyAway:(id)sender
{
     [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
}



- (void)bodytouch:(id)sender
{
    

    

    
    if(state == 0)
    {
        [[SoundManager sharedManager] playSound:@"flash.mp3" looping:NO];

        son1.frame=CGRectMake(75,176,270,250);
        label.frame=CGRectMake(110, 546, 300, 80);
        label2.frame=CGRectMake(120, 576, 300, 80);
        
    UIButton *dna1 = [[UIButton alloc] initWithFrame:CGRectMake(45, 45, 100, 40)];
    [dna1 setBackgroundImage:[UIImage imageNamed:@"9_on"] forState:UIControlStateNormal];
    
    UIButton *dna2 = [[UIButton alloc] initWithFrame:CGRectMake(45, 45, 100, 40)];
    [dna2 setBackgroundImage:[UIImage imageNamed:@"5_on"] forState:UIControlStateNormal];
    
    UIButton *dna3 = [[UIButton alloc] initWithFrame:CGRectMake(45, 45, 100, 40)];
    [dna3 setBackgroundImage:[UIImage imageNamed:@"6_on"] forState:UIControlStateNormal];
    
    UIButton *dna4 = [[UIButton alloc] initWithFrame:CGRectMake(45, 45, 100, 40)];
    [dna4 setBackgroundImage:[UIImage imageNamed:@"2_on"] forState:UIControlStateNormal];
    
    [self.view addSubview:dna1];
    [self.view addSubview:dna2];
    [self.view addSubview:dna3];
    [self.view addSubview:dna4];
    
    UIImageView *circle1 = [[UIImageView alloc] initWithFrame:CGRectMake(110,225,40,40)];
    [circle1 setImage:[UIImage imageNamed:@"circle1.png"]];
    [self.view addSubview:circle1];
    
    UIImageView *circle2 = [[UIImageView alloc] initWithFrame:CGRectMake(110,225,40,40)];
    [circle2 setImage:[UIImage imageNamed:@"circle1.png"]];
    [self.view addSubview:circle2];
    
    UIImageView *circle3 = [[UIImageView alloc] initWithFrame:CGRectMake(110,225,40,40)];
    [circle3 setImage:[UIImage imageNamed:@"circle1.png"]];
    [self.view addSubview:circle3];
    
    UIImageView *circle4 = [[UIImageView alloc] initWithFrame:CGRectMake(110,225,40,40)];
    [circle4 setImage:[UIImage imageNamed:@"circle1.png"]];
    [self.view addSubview:circle4];
    
    dna1.alpha = 0;
    dna1.frame = CGRectMake(195,255, 10,10);
    
    dna2.alpha = 0;
    dna2.frame = CGRectMake(150,177, 10,10);
    
    dna3.alpha = 0;
    dna3.frame = CGRectMake(195,380, 10,10);
    
    dna4.alpha = 0;
    dna4.frame = CGRectMake(235,230, 10,10);
    
    
    
    circle1.alpha = 0;
    circle1.frame = CGRectMake(195,255, 0,0);
    
    circle2.alpha = 0;
    circle2.frame = CGRectMake(150,177, 0,0);
    
    circle3.alpha = 0;
    circle3.frame = CGRectMake(195,380, 0,0);
    
    circle4.alpha = 0;
    circle4.frame = CGRectMake(235,230, 0,0);
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    
    
    
        dna1.alpha = 1;
        dna1.frame = CGRectMake(40,250, 100, 40);
        dna2.alpha = 1;
        dna2.frame = CGRectMake(150,120, 100, 40);
        dna3.alpha = 1;
        dna3.frame = CGRectMake(180,460, 100, 40);
        dna4.alpha = 1;
        dna4.frame = CGRectMake(285,140, 100,40);
        
        
        
        circle1.alpha = 1;
        circle1.frame = CGRectMake(195,255, 40,40);
        circle2.alpha = 1;
        circle2.frame = CGRectMake(150,177, 40,40);
        circle3.alpha = 1;
        circle3.frame = CGRectMake(195,380, 40,40);
        circle4.alpha = 1;
        circle4.frame = CGRectMake(235,230, 40,40);

        
        [UIView commitAnimations];
        
        [AppDelegate storyBoradAutoLay:self.view];
        
        dna1.transform = CGAffineTransformRotate(dna1.transform, M_PI_4*3.7);
        dna2.transform = CGAffineTransformRotate(dna2.transform, M_PI_4*3.7);
        dna3.transform = CGAffineTransformRotate(dna3.transform, M_PI_4*3.7);
        dna4.transform = CGAffineTransformRotate(dna4.transform, M_PI_4*3.7);
        
        state++;
    }
    

}





//点击周围就退出
- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [[event allTouches] anyObject];
   CGPoint touchPoint = [touch locationInView:self.view];
    [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
    state--;
}

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [[event allTouches] anyObject];
   CGPoint touchPoint = [touch locationInView:self.view];
    [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
}














@end
