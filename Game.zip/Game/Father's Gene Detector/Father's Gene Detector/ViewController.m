//
//  ViewController.m
//  Father's Gene Detector
//
//  Created by Bruce on 9/11/15.
//  Copyright (c) 2015 Bruce. All rights reserved.
//

#import "ViewController.h"
#import "QKInfoCard.h"
#import "PureLayout.h"
#import "MRFlipTransition.h"
#import "AnotherViewController1.h"
#import "optionview.h"
#import "AnotherViewController2.h"
#import "AnotherViewController3.h"
#import "AnotherViewController4.h"
#import "AnotherViewController5.h"
#import "LazyFadeInView.h"
#import "score.h"
#import "CUSFlashLabel.h"
#import "AppDelegate.h"

@interface ViewController ()


@property (nonatomic, strong)   MRFlipTransition    *animator;
@property(weak,nonatomic) IBOutlet UIImageView* thunder;


@end

@implementation ViewController {
    
    QKInfoCard *_infoCard;
    
}


- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    
    
    
    
    
    
    //main background
    
    _infoCard = [[QKInfoCard alloc] initWithView:self.view];
    
    
    UIImageView  *background=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 375, 667)];
    [background setImage:[UIImage imageNamed:@"bg.png"]];
    [self.view addSubview:background];
    
    
    
    
    
    
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    
    
    
    
    //title
    
    
    UIImageView *title = [[UIImageView alloc] initWithFrame:CGRectMake(20,0,350,600)];
    [title setImage:[UIImage imageNamed:@"title(1).png"]];
    // title.transform = CGAffineTransformRotate(title.transform, M_PI_4*-0.12);
    
    
    /*
     title.frame =CGRectMake(60,-10,300,600);
     [UIView beginAnimations:nil context:nil];
     [UIView setAnimationDuration:10.0];
     title.frame =CGRectMake(20,20,340,600);
     [UIView commitAnimations];*/
    
    [UIView animateWithDuration:1000.0 delay:0 usingSpringWithDamping:0 initialSpringVelocity:0.0007 options:UIViewAnimationOptionCurveLinear animations:^{
        title.center=CGPointMake(195,297);
    } completion:nil];
    
    
    
    
    
    
    //about bgm
    
    [SoundManager sharedManager].allowsBackgroundMusic = YES;
    [[SoundManager sharedManager] prepareToPlay];
    [[SoundManager sharedManager] playMusic:@"梅花三弄.mp3" looping:YES];
    
    
    //about cloud
    
    
    UIImageView  *cloud=[[UIImageView alloc] initWithFrame:CGRectMake(100, 200, 150, 133)];
    [cloud setImage:[UIImage imageNamed:@"cloud.png"]];
    cloud.alpha = 0.7;
    UIImageView  *cloud1=[[UIImageView alloc] initWithFrame:CGRectMake(100, 200, 150, 133)];
    [cloud1 setImage:[UIImage imageNamed:@"cloud1.png"]];
    cloud1.alpha = 1;
    UIImageView  *cloud2=[[UIImageView alloc] initWithFrame:CGRectMake(100, 200, 150, 133)];
    [cloud2 setImage:[UIImage imageNamed:@"cloud2.png"]];
    cloud2.alpha = 0.8;
    cloud.frame = CGRectMake(-100,160, 150, 133);
    cloud1.frame = CGRectMake(-300,250, 150, 133);
    cloud2.frame = CGRectMake(-500,180, 150, 133);
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:100.0];
    cloud.frame = CGRectMake(800,160, 150, 133);
    cloud1.frame = CGRectMake(400,250, 150, 133);
    cloud2.frame = CGRectMake(200,180, 150, 133);
    [UIView commitAnimations];
    [self.view addSubview:cloud2];
    [self.view addSubview:cloud];
    [self.view addSubview:title];
    [self.view addSubview:cloud1];
    
    
    
    /////////////////////////////
    
    [UIView animateWithDuration:1000.0 delay:0 usingSpringWithDamping:0 initialSpringVelocity:0.0002 options:UIViewAnimationOptionCurveLinear animations:^{
        cloud2.center=CGPointMake(240,250);
    } completion:nil];
    
    
    
    
    
    
    
    //about start button & option button
    
    UIImageView *bihen = [[UIImageView alloc] initWithFrame:CGRectMake(20,330,280,80)];
    [bihen setImage:[UIImage imageNamed:@"bihen.png"]];
    
    [self.view addSubview:bihen];
    
    
    UIImageView *bihen2 = [[UIImageView alloc] initWithFrame:CGRectMake(20,430,280,80)];
    [bihen2 setImage:[UIImage imageNamed:@"bihen.png"]];
    
    [self.view addSubview:bihen2];
    
    UIButton *start = [[UIButton alloc] initWithFrame:CGRectMake(90, 400, 190, 130)];
    [start addTarget:self action:@selector(showoption:) forControlEvents:UIControlEventTouchUpInside];
    [start setBackgroundImage:[UIImage imageNamed:@"optionw"] forState:UIControlStateNormal];
    //[start setBackgroundImage:[UIImage imageNamed:@"option"] forState:UIControlStateHighlighted];
    [self.view addSubview:start];
    
    UIButton *option = [[UIButton alloc] initWithFrame:CGRectMake(90, 300, 210, 130)];
    [option addTarget:self action:@selector(show:) forControlEvents:UIControlEventTouchUpInside];
    [option setBackgroundImage:[UIImage imageNamed:@"startw"] forState:UIControlStateNormal];
    //[option setBackgroundImage:[UIImage imageNamed:@"option"] forState:UIControlStateHighlighted];
    [self.view addSubview:option];
    
    
    
    
    
    
    [AppDelegate storyBoradAutoLay:self.view];
    
    
    
    
    
    
    //son cardview
    for (int i = 0; i < 6; i ++) {
        
        //1st son
        
        if (i==0) {
            
            
            UIView *viewToAdd = [[UIView alloc] init];
            
            
            UIImageView *imgShadow = [[UIImageView alloc] initWithFrame:CGRectMake(-450,-15,2400,435)];
            [imgShadow setImage:[UIImage imageNamed:@"bg4.png"]];
            [viewToAdd addSubview:imgShadow];
            
            
            UIImageView *sea = [[UIImageView alloc] initWithFrame:CGRectMake(0,120,310,250)];
            [sea setImage:[UIImage imageNamed:@"sea.png"]];
            [viewToAdd addSubview:sea];
            
            
            
            UIButton *son4zi = [[UIButton alloc] initWithFrame:CGRectMake(20,40,50,120)];
            //[son4zi addTarget:self action:@selector(textfade:) forControlEvents:UIControlEventTouchUpInside];
            [son4zi setBackgroundImage:[UIImage imageNamed:@"son4zi"] forState:UIControlStateNormal];
            [son4zi setBackgroundImage:[UIImage imageNamed:@"yz gray"] forState:UIControlStateHighlighted];
            son4zi.alpha = 0.95;
            [viewToAdd addSubview:son4zi];
            
            UIButton *son4 = [[UIButton alloc] initWithFrame:CGRectMake(55,40,260,270)];
            [son4 addTarget:self action:@selector(showAnotherController4:) forControlEvents:UIControlEventTouchUpInside];
            [son4 setBackgroundImage:[UIImage imageNamed:@"son4_off"] forState:UIControlStateNormal];
            [son4 setBackgroundImage:[UIImage imageNamed:@"son4_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:son4];
            
            UIButton *pinyinba = [[UIButton alloc] initWithFrame:CGRectMake(0,140,100,100)];
            [pinyinba addTarget:self action:@selector(showAnotherController4:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinba setBackgroundImage:[UIImage imageNamed:@"pinyinba.png"] forState:UIControlStateNormal];
            pinyinba.alpha = 0.85;
            [viewToAdd addSubview:pinyinba];
            
            UIButton *pinyinxia = [[UIButton alloc] initWithFrame:CGRectMake(-5,175,100,100)];
            [pinyinxia addTarget:self action:@selector(showAnotherController4:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinxia setBackgroundImage:[UIImage imageNamed:@"pinyinxia.png"] forState:UIControlStateNormal];
            pinyinxia.alpha = 0.85;
            [viewToAdd addSubview:pinyinxia];
            
            
            
            
            
            
            
            
            self.smokeEmitter	= [CAEmitterLayer layer];
            self.smokeEmitter.emitterPosition = CGPointMake(150,280);
            self.smokeEmitter.emitterMode	= kCAEmitterLayerPoints;
            
            
            CAEmitterCell* bubble = [CAEmitterCell emitterCell];
            [bubble setName:@"smoke "];
            
            bubble.birthRate			= 8;
            bubble.emissionLongitude = -M_PI / 2;
            bubble.lifetime			= 10;
            bubble.velocity			= -20;
            bubble.velocityRange		= 20;
            bubble.emissionRange		= 5.0;
            bubble.spin				= 0;
            bubble.spinRange			= 10;
            bubble.yAcceleration		= -160;
            bubble.contents			= (id) [[UIImage imageNamed:@"bubble small"] CGImage];
            bubble.scale				= 0.1;
            bubble.alphaSpeed		= -0.12;
            bubble.scaleSpeed		= 0.7;
            
            self.smokeEmitter.emitterCells	= [NSArray arrayWithObject:bubble];
            [viewToAdd.layer addSublayer:self.smokeEmitter];
            
            [array addObject:viewToAdd];
            [AppDelegate storyBoradAutoLay:viewToAdd];
            
            
            
            
            
        }
        //2nd son
        
        else if(i==1){
            
            
            
            
            UIView *viewToAdd = [[UIView alloc] init];
            
            UIButton *son2zi = [[UIButton alloc] initWithFrame:CGRectMake(20,40,50,120)];
            //[son2zi addTarget:self action:@selector(show:) forControlEvents:UIControlEventTouchUpInside];
            [son2zi setBackgroundImage:[UIImage imageNamed:@"son1zi"] forState:UIControlStateNormal];
            [son2zi setBackgroundImage:[UIImage imageNamed:@"cf gray"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:son2zi];
            
            UIButton *son2 = [[UIButton alloc] initWithFrame:CGRectMake(55, 50,260,260)];
            [son2 addTarget:self action:@selector(showAnotherController2:) forControlEvents:UIControlEventTouchUpInside];
            [son2 setBackgroundImage:[UIImage imageNamed:@"son1_off"] forState:UIControlStateNormal];
            [son2 setBackgroundImage:[UIImage imageNamed:@"son1_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:son2];
            //            [AppDelegate storyBoradAutoLay:viewToAdd];
            
            UIButton *pinyinchao = [[UIButton alloc] initWithFrame:CGRectMake(0,155,80,80)];
            [pinyinchao addTarget:self action:@selector(showAnotherController2:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinchao setBackgroundImage:[UIImage imageNamed:@"pinyinchao.png"] forState:UIControlStateNormal];
            pinyinchao.alpha = 0.85;
            [viewToAdd addSubview:pinyinchao];
            
            UIButton *pinyinfeng = [[UIButton alloc] initWithFrame:CGRectMake(0,190,80,80)];
            [pinyinfeng addTarget:self action:@selector(showAnotherController2:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinfeng setBackgroundImage:[UIImage imageNamed:@"pinyinfeng.png"] forState:UIControlStateNormal];
            pinyinfeng.alpha = 0.85;
            [viewToAdd addSubview:pinyinfeng];
            
            
            
            
            [array addObject:viewToAdd];
            
            
            
            CGRect viewBounds = self.view.layer.bounds;
            
            // Create the emitter layers
            self.fireEmitter	= [CAEmitterLayer layer];
            
            // Place layers just above the tab bar
            self.fireEmitter.emitterPosition = CGPointMake(165,250);
            self.fireEmitter.emitterSize	= CGSizeMake(viewBounds.size.width/1.0, 0);
            self.fireEmitter.emitterMode	= kCAEmitterLayerOutline;
            self.fireEmitter.emitterShape	= kCAEmitterLayerLine;
            // with additive rendering the dense cell distribution will create "hot" areas
            self.fireEmitter.renderMode		= kCAEmitterLayerAdditive;
            // Create the fire emitter cell
            CAEmitterCell* fire = [CAEmitterCell emitterCell];
            [fire setName:@"fire"];
            
            fire.birthRate			= 50;
            fire.emissionLongitude  = M_PI;
            fire.velocity			= -80;
            fire.velocityRange		= 30;
            fire.emissionRange		= 2.0;
            fire.yAcceleration		= -200;
            fire.scaleSpeed			= 0.3;
            fire.lifetime			= 50;
            fire.lifetimeRange		= (50.0 * 0.35);
            
            fire.color = [[UIColor colorWithRed:0.8 green:0.4 blue:0.2 alpha:0.1] CGColor];
            fire.contents = (id) [[UIImage imageNamed:@"DazFire"] CGImage];
            self.fireEmitter.emitterCells	= [NSArray arrayWithObject:fire];
            [viewToAdd.layer addSublayer:self.fireEmitter];
            
            [self setFireAmount:0.9];
            [AppDelegate storyBoradAutoLay:viewToAdd];
            
        }
        
        //3rd son
        
        
        else if (i==2){
            UIView *viewToAdd = [[UIView alloc] init];
            
            UIButton *son3zi = [[UIButton alloc] initWithFrame:CGRectMake(20,40,50,120)];
            //[son3zi addTarget:self action:@selector(showAnotherController:) forControlEvents:UIControlEventTouchUpInside];
            [son3zi setBackgroundImage:[UIImage imageNamed:@"son3zi"] forState:UIControlStateNormal];
            [son3zi setBackgroundImage:[UIImage imageNamed:@"yz gray"] forState:UIControlStateHighlighted];
            son3zi.alpha = 0.95;
            [viewToAdd addSubview:son3zi];
            
            UIButton *son3 = [[UIButton alloc] initWithFrame:CGRectMake(55,40,270,270)];
            [son3 addTarget:self action:@selector(showAnotherController3:) forControlEvents:UIControlEventTouchUpInside];
            [son3 setBackgroundImage:[UIImage imageNamed:@"son3_off"] forState:UIControlStateNormal];
            [son3 setBackgroundImage:[UIImage imageNamed:@"son3_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:son3];
            
            
            UIButton *pinyinya = [[UIButton alloc] initWithFrame:CGRectMake(0,147,100,100)];
            [pinyinya addTarget:self action:@selector(showAnotherController3:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinya setBackgroundImage:[UIImage imageNamed:@"pinyinya.png"] forState:UIControlStateNormal];
            pinyinya.alpha = 0.85;
            [viewToAdd addSubview:pinyinya];
            
            
            UIButton *pinyinzi = [[UIButton alloc] initWithFrame:CGRectMake(0,185,90,90)];
            [pinyinzi addTarget:self action:@selector(showAnotherController3:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinzi setBackgroundImage:[UIImage imageNamed:@"pinyinzi.png"] forState:UIControlStateNormal];
            pinyinzi.alpha = 0.85;
            [viewToAdd addSubview:pinyinzi];
            
            
            
            
            
            
            [array addObject:viewToAdd];
            
            CAEmitterLayer *snowEmitter = [CAEmitterLayer layer];
            snowEmitter.emitterPosition = CGPointMake(175, -30);
            snowEmitter.emitterSize		= CGSizeMake(self.view.bounds.size.width * 0.4, 0.0);;
            // Spawn points for the flakes are within on the outline of the line
            snowEmitter.emitterMode		= kCAEmitterLayerOutline;
            snowEmitter.emitterShape	= kCAEmitterLayerLine;
            // Configure the snowflake emitter cell
            CAEmitterCell *snowflake = [CAEmitterCell emitterCell];
            snowflake.birthRate		= 0.5;
            snowflake.lifetime		= 120.0;
            snowflake.velocity		= -5;				// falling down slowly
            snowflake.velocityRange = 10;
            snowflake.yAcceleration = 2;
            snowflake.emissionRange = 0.1 * M_PI;		// some variation in angle
            snowflake.spinRange		= 0.04 * M_PI;		// slow spin
            snowflake.contents		= (id) [[UIImage imageNamed:@"snow"] CGImage];
            snowflake.color			= [[UIColor colorWithRed:1.000 green:1.000 blue:1.000 alpha:1.000] CGColor];
            // Make the flakes seem inset in the background
            snowEmitter.shadowOpacity = 1.0;
            snowEmitter.shadowRadius  = 0.0;
            snowEmitter.shadowOffset  = CGSizeMake(0.0, 1.0);
            snowEmitter.shadowColor   = [[UIColor whiteColor] CGColor];
            // Add everything to our backing layer below the UIContol defined in the storyboard
            snowEmitter.emitterCells = [NSArray arrayWithObject:snowflake];
            [viewToAdd.layer insertSublayer:snowEmitter atIndex:1];
            
            
            CAEmitterLayer *snowEmitter2 = [CAEmitterLayer layer];
            snowEmitter2.emitterPosition = CGPointMake(175, -30);
            snowEmitter2.emitterSize		= CGSizeMake(self.view.bounds.size.width * 0.5, 0.0);;
            // Spawn points for the flakes are within on the outline of the line
            snowEmitter2.emitterMode		= kCAEmitterLayerOutline;
            snowEmitter2.emitterShape	= kCAEmitterLayerLine;
            // Configure the snowflake emitter cell
            CAEmitterCell *snowflake2 = [CAEmitterCell emitterCell];
            snowflake2.birthRate		= 1;
            snowflake2.lifetime		= 120.0;
            snowflake2.velocity		= -5;				// falling down slowly
            snowflake2.velocityRange = 10;
            snowflake2.yAcceleration = 2;
            snowflake2.emissionRange = 0.1 * M_PI;		// some variation in angle
            snowflake2.spinRange		= 0.04 * M_PI;		// slow spin
            snowflake2.contents		= (id) [[UIImage imageNamed:@"snow2"] CGImage];
            snowflake2.color			= [[UIColor colorWithRed:1.000 green:1.000 blue:1.000 alpha:1.000] CGColor];
            // Make the flakes seem inset in the background
            snowEmitter2.shadowOpacity = 1.0;
            snowEmitter2.shadowRadius  = 0.0;
            snowEmitter2.shadowOffset  = CGSizeMake(0.0, 1.0);
            snowEmitter2.shadowColor   = [[UIColor whiteColor] CGColor];
            // Add everything to our backing layer below the UIContol defined in the storyboard
            snowEmitter2.emitterCells = [NSArray arrayWithObject:snowflake2];
            [viewToAdd.layer insertSublayer:snowEmitter2 atIndex:0];
            [AppDelegate storyBoradAutoLay:viewToAdd];
            
            
        }
        //4th son
        
        else if (i==3){
            
            UIView *viewToAdd = [[UIView alloc] init];
            
            
            
            UIImageView *sky = [[UIImageView alloc] initWithFrame:CGRectMake(30,220,187,105)];
            [sky setImage:[UIImage imageNamed:@"sky.png"]];
            
            [viewToAdd addSubview:sky];
            
            
            UIButton *son1 = [[UIButton alloc] initWithFrame:CGRectMake(40, 50,270,250)];
            [son1 addTarget:self action:@selector(showAnotherController:) forControlEvents:UIControlEventTouchUpInside];
            [son1 setBackgroundImage:[UIImage imageNamed:@"son2_off"] forState:UIControlStateNormal];
            [son1 setBackgroundImage:[UIImage imageNamed:@"son2_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:son1];
            
            UIButton *son1zi = [[UIButton alloc] initWithFrame:CGRectMake(20,40,40,140)];
            //[son1zi addTarget:self action:@selector(setTextBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
            [son1zi setBackgroundImage:[UIImage imageNamed:@"son2zi"] forState:UIControlStateNormal];
            [son1zi setBackgroundImage:[UIImage imageNamed:@"qn gray"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:son1zi];
            
            
            
            UIButton *pinyinqiu = [[UIButton alloc] initWithFrame:CGRectMake(-10, 170,80,80)];
            [pinyinqiu addTarget:self action:@selector(showAnotherController:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinqiu setBackgroundImage:[UIImage imageNamed:@"pinyinqiu.png"] forState:UIControlStateNormal];
            pinyinqiu.alpha = 0.85;
            [viewToAdd addSubview:pinyinqiu];
            
            UIButton *pinyinniu = [[UIButton alloc] initWithFrame:CGRectMake(-10, 215,80,80)];
            [pinyinniu addTarget:self action:@selector(showAnotherController:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinniu setBackgroundImage:[UIImage imageNamed:@"pinyinniu.png"] forState:UIControlStateNormal];
            pinyinniu.alpha = 0.85;
            [viewToAdd addSubview:pinyinniu];
            
            
            
            ///////////////////////
            
            
            UIImageView *sky1 = [[UIImageView alloc] initWithFrame:CGRectMake(50,220,187,105)];
            [sky1 setImage:[UIImage imageNamed:@"sky2.png"]];
            
            [viewToAdd addSubview:sky1];
            UIImageView *sky2 = [[UIImageView alloc] initWithFrame:CGRectMake(70,220,187,105)];
            [sky2 setImage:[UIImage imageNamed:@"sky3.png"]];
            
            [viewToAdd addSubview:sky2];
            
            
            ////////////////////
            
            self.smokeEmitter	= [CAEmitterLayer layer];
            self.smokeEmitter.emitterPosition = CGPointMake(160,290);
            self.smokeEmitter.emitterMode	= kCAEmitterLayerPoints;
            
            
            CAEmitterCell* smoke = [CAEmitterCell emitterCell];
            [smoke setName:@"smoke"];
            
            smoke.birthRate			=6;
            smoke.emissionLongitude = -M_PI / 2;
            smoke.lifetime			= 10;
            smoke.velocity			= -40;
            smoke.velocityRange		= 20;
            smoke.emissionRange		= 5.0;
            smoke.spin				= 1;
            smoke.spinRange			= 10;
            smoke.yAcceleration		= -160;
            smoke.contents			= (id) [[UIImage imageNamed:@"DazSmoke"] CGImage];
            smoke.scale				= 0.1;
            smoke.alphaSpeed		= -0.0;
            smoke.scaleSpeed		= 0.7;
            
            self.smokeEmitter.emitterCells	= [NSArray arrayWithObject:smoke];
            [viewToAdd.layer addSublayer:self.smokeEmitter];
            [array addObject:viewToAdd];
            [AppDelegate storyBoradAutoLay:viewToAdd];
        }
        
        //5th son
        
        else if (i==4){
            
            
            UIView *viewToAdd = [[UIView alloc] init];
            CGRect viewBounds = viewToAdd.layer.bounds;
            self.fireEmitter	= [CAEmitterLayer layer];
            self.fireEmitter.emitterPosition = CGPointMake(155,180);
            self.fireEmitter.emitterSize	= CGSizeMake(viewBounds.size.width/1.0, 0);
            self.fireEmitter.emitterMode	= kCAEmitterLayerOutline;
            self.fireEmitter.emitterShape	= kCAEmitterLayerLine;
            self.fireEmitter.renderMode		= kCAEmitterLayerAdditive;
            CAEmitterCell* thunder = [CAEmitterCell emitterCell];
            [thunder setName:@"thunder2"];
            thunder.birthRate			= 1;
            thunder.emissionLongitude  = M_PI;
            thunder.velocity			= 0;
            thunder.velocityRange		= 0;
            thunder.emissionRange		= 0.2;
            thunder.yAcceleration		= 0.2;
            thunder.scaleSpeed			= 0.1;
            thunder.lifetime			= 0.5;
            thunder.lifetimeRange		= (50.0 * 0.1);
            thunder.contents = (id) [[UIImage imageNamed:@"thunder2"] CGImage];
            self.fireEmitter.emitterCells	= [NSArray arrayWithObject:thunder];
            [viewToAdd.layer addSublayer:self.fireEmitter];
            
            UIButton *son5 = [[UIButton alloc] initWithFrame:CGRectMake(55, 65,243,234)];
            [son5 addTarget:self action:@selector(showAnotherController5:) forControlEvents:UIControlEventTouchUpInside];
            [son5 setBackgroundImage:[UIImage imageNamed:@"son5_off"] forState:UIControlStateNormal];
            [son5 setBackgroundImage:[UIImage imageNamed:@"son5_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:son5];
            
            UIButton *son5zi = [[UIButton alloc] initWithFrame:CGRectMake(20,40,50,140)];
            // [son5zi addTarget:self action:@selector(show:) forControlEvents:UIControlEventTouchUpInside];
            [son5zi setBackgroundImage:[UIImage imageNamed:@"PXblack"] forState:UIControlStateNormal];
            [son5zi setBackgroundImage:[UIImage imageNamed:@"PXgray"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:son5zi];
            
            UIButton *pinyinpi = [[UIButton alloc] initWithFrame:CGRectMake(2, 163, 80, 80)];
            [pinyinpi addTarget:self action:@selector(showAnotherController:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinpi setBackgroundImage:[UIImage imageNamed:@"pinyinpi.png"] forState:UIControlStateNormal];
            pinyinpi.alpha = 0.85;
            [viewToAdd addSubview:pinyinpi];
            
            UIButton *pinyinxiu = [[UIButton alloc] initWithFrame:CGRectMake(0,200,80,80)];
            [pinyinxiu addTarget:self action:@selector(showAnotherController:) forControlEvents:UIControlEventTouchUpInside];
            [pinyinxiu setBackgroundImage:[UIImage imageNamed:@"pinyinxiu.png"] forState:UIControlStateNormal];
            pinyinxiu.alpha = 0.85;
            [viewToAdd addSubview:pinyinxiu];
            
            
            
            
            //            [AppDelegate storyBoradAutoLay:viewToAdd];
            
            self.thunderEmitter	= [CAEmitterLayer layer];
            self.thunderEmitter.emitterPosition = CGPointMake(165,180);
            self.thunderEmitter.emitterSize	= CGSizeMake(viewBounds.size.width/1.0, 0);
            self.thunderEmitter.emitterMode	= kCAEmitterLayerOutline ;
            self.thunderEmitter.emitterShape	= kCAEmitterLayerLine;
            self.thunderEmitter.renderMode		= kCAEmitterLayerAdditive;
            CAEmitterCell* thunder2 = [CAEmitterCell emitterCell];
            [thunder2 setName:@"thunder1"];
            thunder2.birthRate			= 1;
            thunder2.emissionLongitude  = M_PI;
            thunder2.velocity			= 0;
            thunder2.velocityRange		= 0;
            thunder2.emissionRange		= 1;
            thunder2.yAcceleration		= 0.2;
            thunder2.scaleSpeed			= 0.02;
            thunder2.lifetime			= 1.5;
            thunder2.lifetimeRange		= (50.0 * 0.1);
            thunder2.contents = (id) [[UIImage imageNamed:@"thunder1"] CGImage];
            self.thunderEmitter.emitterCells	= [NSArray arrayWithObject:thunder2];
            [viewToAdd.layer addSublayer:self.thunderEmitter];
            [self setFireAmount:0.9];
            [array addObject:viewToAdd];
            
            [AppDelegate storyBoradAutoLay:viewToAdd];
        }
        
        //DNAselect
        else if (i==5)
        {
            
            UIView *viewToAdd = [[UIView alloc] init];
            
            
            //father init
            
            daddy = [[UIButton alloc] initWithFrame:CGRectMake(-20, -20, 350, 350)];
            //            [daddy addTarget:self action:@selector(showAnotherController:) forControlEvents:UIControlEventTouchUpInside];
            [daddy setBackgroundImage:[UIImage imageNamed:@"0long"] forState:UIControlStateNormal];
            //            [daddy setBackgroundImage:[UIImage imageNamed:@"son5_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:daddy];
            
            
            
            //submit button
            
            UIImageView *bihens = [[UIImageView alloc] initWithFrame:CGRectMake(0,300,200,130)];
            [bihens setImage:[UIImage imageNamed:@"qianbihen.png"]];
            bihens.alpha = 0.8;
            [viewToAdd addSubview:bihens];
            
            bsubmit = [[UIButton alloc] initWithFrame:CGRectMake(30, 310, 130, 60)];
            [bsubmit addTarget:self action:@selector(submit:) forControlEvents:UIControlEventTouchUpInside];
            [bsubmit setBackgroundImage:[UIImage imageNamed:@"submit"] forState:UIControlStateNormal];
            [bsubmit setBackgroundImage:[UIImage imageNamed:@"submit_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:bsubmit];
            
            
            
            
            
            circle11 = [[UIButton alloc] initWithFrame:CGRectMake(125, 70, 40, 40)];
            [circle11 addTarget:self action:@selector(circleselect11:) forControlEvents:UIControlEventTouchUpInside];
            [circle11 setBackgroundImage:[UIImage imageNamed:@"circle1"] forState:UIControlStateNormal];
            //            [daddy setBackgroundImage:[UIImage imageNamed:@"son5_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:circle11];
            
            circle10 = [[UIButton alloc] initWithFrame:CGRectMake(-15, 325, 233, 43)];
            [circle10 addTarget:self action:@selector(circleselect10:) forControlEvents:UIControlEventTouchUpInside];
            [circle10 setBackgroundImage:[UIImage imageNamed:@"back2"] forState:UIControlStateNormal];
            circle10.alpha = 0;
            [viewToAdd addSubview:circle10];
            
            
            circle21 = [[UIButton alloc] initWithFrame:CGRectMake(136, 22, 40, 40)];
            [circle21 addTarget:self action:@selector(circleselect21:) forControlEvents:UIControlEventTouchUpInside];
            [circle21 setBackgroundImage:[UIImage imageNamed:@"circle1"] forState:UIControlStateNormal];
            //            [daddy setBackgroundImage:[UIImage imageNamed:@"son5_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:circle21];
            
            circle20 = [[UIButton alloc] initWithFrame:CGRectMake(-15, 325, 233, 43)];
            [circle20 addTarget:self action:@selector(circleselect20:) forControlEvents:UIControlEventTouchUpInside];
            [circle20 setBackgroundImage:[UIImage imageNamed:@"back2"] forState:UIControlStateNormal];
            circle20.alpha = 0;
            [viewToAdd addSubview:circle20];
            
            
            circle31 = [[UIButton alloc] initWithFrame:CGRectMake(55, 183, 40, 40)];
            [circle31 addTarget:self action:@selector(circleselect31:) forControlEvents:UIControlEventTouchUpInside];
            [circle31 setBackgroundImage:[UIImage imageNamed:@"circle1"] forState:UIControlStateNormal];
            [viewToAdd addSubview:circle31];
            
            circle30 = [[UIButton alloc] initWithFrame:CGRectMake(-15, 325, 233, 43)];
            [circle30 addTarget:self action:@selector(circleselect30:) forControlEvents:UIControlEventTouchUpInside];
            [circle30 setBackgroundImage:[UIImage imageNamed:@"back2"] forState:UIControlStateNormal];
            circle30.alpha = 0;
            [viewToAdd addSubview:circle30];
            
            
            circle41 = [[UIButton alloc] initWithFrame:CGRectMake(90, 250, 40, 40)];
            [circle41 addTarget:self action:@selector(circleselect41:) forControlEvents:UIControlEventTouchUpInside];
            [circle41 setBackgroundImage:[UIImage imageNamed:@"circle1"] forState:UIControlStateNormal];
            //            [daddy setBackgroundImage:[UIImage imageNamed:@"son5_on"] forState:UIControlStateHighlighted];
            [viewToAdd addSubview:circle41];
            
            circle40 = [[UIButton alloc] initWithFrame:CGRectMake(-15, 325, 233, 43)];
            [circle40 addTarget:self action:@selector(circleselect40:) forControlEvents:UIControlEventTouchUpInside];
            [circle40 setBackgroundImage:[UIImage imageNamed:@"back2"] forState:UIControlStateNormal];
            circle40.alpha = 0;
            [viewToAdd addSubview:circle40];
            
            
            
            
            //dna init
            
            dna1 = [[UIButton alloc] initWithFrame:CGRectMake(20, 140, 100, 40)];
            [dna1 addTarget:self action:@selector(Dnaselect1:) forControlEvents:UIControlEventTouchUpInside];
            [dna1 setBackgroundImage:[UIImage imageNamed:@"blueb"] forState:UIControlStateNormal];
            dna1.alpha = 0;
            [viewToAdd addSubview:dna1];
            
            dna2 = [[UIButton alloc] initWithFrame:CGRectMake(170, 90, 100, 40)];
            [dna2 addTarget:self action:@selector(Dnaselect2:) forControlEvents:UIControlEventTouchUpInside];
            [dna2 setBackgroundImage:[UIImage imageNamed:@"2_off"] forState:UIControlStateNormal];
            dna2.alpha = 0;
            [viewToAdd addSubview:dna2];
            
            
            
            dna3 = [[UIButton alloc] initWithFrame:CGRectMake(20, 205, 100, 40)];
            [dna3 addTarget:self action:@selector(Dnaselect3:) forControlEvents:UIControlEventTouchUpInside];
            [dna3 setBackgroundImage:[UIImage imageNamed:@"3_off"] forState:UIControlStateNormal];
            dna3.alpha = 0;
            [viewToAdd addSubview:dna3];
            
            
            dna4 = [[UIButton alloc] initWithFrame:CGRectMake(90, 180, 100, 40)];
            [dna4 addTarget:self action:@selector(Dnaselect4:) forControlEvents:UIControlEventTouchUpInside];
            [dna4 setBackgroundImage:[UIImage imageNamed:@"4_off"] forState:UIControlStateNormal];
            dna4.alpha = 0;
            [viewToAdd addSubview:dna4];
            
            
            dna5 = [[UIButton alloc] initWithFrame:CGRectMake(140, 270, 100, 40)];
            [dna5 addTarget:self action:@selector(Dnaselect5:) forControlEvents:UIControlEventTouchUpInside];
            [dna5 setBackgroundImage:[UIImage imageNamed:@"5_off"] forState:UIControlStateNormal];
            dna5.alpha = 0;
            [viewToAdd addSubview:dna5];
            
            dna6 = [[UIButton alloc] initWithFrame:CGRectMake(20, 245, 100, 40)];
            [dna6 addTarget:self action:@selector(Dnaselect6:) forControlEvents:UIControlEventTouchUpInside];
            [dna6 setBackgroundImage:[UIImage imageNamed:@"6_off"] forState:UIControlStateNormal];
            dna6.alpha = 0;
            [viewToAdd addSubview:dna6];
            
            
            dna7 = [[UIButton alloc] initWithFrame:CGRectMake(5, 90, 100, 40)];
            [dna7 addTarget:self action:@selector(Dnaselect7:) forControlEvents:UIControlEventTouchUpInside];
            [dna7 setBackgroundImage:[UIImage imageNamed:@"7_off"] forState:UIControlStateNormal];
            dna7.alpha = 0;
            [viewToAdd addSubview:dna7];
            
            
            dna8 = [[UIButton alloc] initWithFrame:CGRectMake(20, 20, 100, 40)];
            [dna8 addTarget:self action:@selector(Dnaselect8:) forControlEvents:UIControlEventTouchUpInside];
            [dna8 setBackgroundImage:[UIImage imageNamed:@"8_off"] forState:UIControlStateNormal];
            dna8.alpha = 0;
            [viewToAdd addSubview:dna8];
            
            
            dna9 = [[UIButton alloc] initWithFrame:CGRectMake(170, 20, 100, 40)];
            [dna9 addTarget:self action:@selector(Dnaselect9:) forControlEvents:UIControlEventTouchUpInside];
            [dna9 setBackgroundImage:[UIImage imageNamed:@"9_off"] forState:UIControlStateNormal];
            dna9.alpha = 0;
            [viewToAdd addSubview:dna9];
            
            
            dna10 = [[UIButton alloc] initWithFrame:CGRectMake(20, 75, 100, 40)];
            [dna10 addTarget:self action:@selector(Dnaselect10:) forControlEvents:UIControlEventTouchUpInside];
            [dna10 setBackgroundImage:[UIImage imageNamed:@"10_off"] forState:UIControlStateNormal];
            dna10.alpha = 0;
            [viewToAdd addSubview:dna10];
            
            
            /////////////////////////////////
            
            
            
            [AppDelegate storyBoradAutoLay:viewToAdd];
            
            
            dna1.transform = CGAffineTransformRotate(dna1.transform, M_PI_4*3.7);
            dna2.transform = CGAffineTransformRotate(dna2.transform, M_PI_4*3.7);
            dna3.transform = CGAffineTransformRotate(dna3.transform, M_PI_4*3.7);
            dna4.transform = CGAffineTransformRotate(dna4.transform, M_PI_4*3.7);
            dna5.transform = CGAffineTransformRotate(dna5.transform, M_PI_4*3.7);
            dna6.transform = CGAffineTransformRotate(dna6.transform, M_PI_4*3.7);
            dna7.transform = CGAffineTransformRotate(dna7.transform, M_PI_4*3.7);
            dna8.transform = CGAffineTransformRotate(dna8.transform, M_PI_4*3.7);
            dna9.transform = CGAffineTransformRotate(dna9.transform, M_PI_4*3.7);
            dna10.transform = CGAffineTransformRotate(dna10.transform, M_PI_4*3.7);
            bihens.transform = CGAffineTransformRotate(bihens.transform, M_PI_4*-0.3);
            bsubmit.transform = CGAffineTransformRotate(bsubmit.transform, M_PI_4*-0.3);
            circle10.transform = CGAffineTransformRotate(bsubmit.transform, M_PI_4*-0.1);
            circle20.transform = CGAffineTransformRotate(bsubmit.transform, M_PI_4*-0.1);
            circle30.transform = CGAffineTransformRotate(bsubmit.transform, M_PI_4*-0.1);
            circle40.transform = CGAffineTransformRotate(bsubmit.transform, M_PI_4*-0.1);
            
            
            [array addObject:viewToAdd];
            
        }
        
        _infoCard.containerSubviews = array;
        [self.view addSubview:_infoCard];
        
    }
    
    
    
    
}




//set timer
- (void)paint:(NSTimer *)paramTimer{
    
    NSLog(@"定时器执行的方法");
}


- (void) startPainting{
    
    // 定义一个NSTime
    self.paintingTimer = [NSTimer scheduledTimerWithTimeInterval:25.0 target:self selector:@selector(paint:)  userInfo:nil repeats:YES];
}



// 停止定时器
- (void) stopPainting{
    if (self.paintingTimer != nil){
        // 定时器调用invalidate后，就会自动执行release方法。不需要在显示的调用release方法
        [self.paintingTimer invalidate];
    }
}




//

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self showIntroWithCrossDissolve];
    
}

- (void)viewDidAppear:(BOOL)animated {
    //    [[UIApplication sharedApplication].keyWindow addSubview:_infoCard];
    [self startPainting];
    [super viewDidAppear:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    [self stopPainting];
    [_infoCard removeFromSuperview];
    [super viewDidDisappear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}







- (void)show:(__unused UIButton *)sender
{
    
    [[SoundManager sharedManager] playSound:@"buttontouch.mp3" looping:NO];
    
    [_infoCard show];
    
}
- (void)showAnotherController:(id)sender
{
    if(stateview[0]==0){
        
        
        
        [[SoundManager sharedManager] playSound:@"cow.mp3" looping:NO];
        stateview[0]++;
    }
    
    
    self.animator = [[MRFlipTransition alloc] initWithPresentingViewController:self presentBlock:^UIViewController *{
        return [[AnotherViewController1 alloc] initWithNibName:nil bundle:nil];
    }];
    
    [self.animator presentFrom:MRFlipTransitionPresentingFromBottom completion:nil];
    
}
- (void)showAnotherController2:(id)sender
{
    
    if(stateview[1]==0){
        
        
        
        [[SoundManager sharedManager] playSound:@"fire.mp3" looping:NO];
        stateview[1]++;
    }
    
    self.animator = [[MRFlipTransition alloc] initWithPresentingViewController:self presentBlock:^UIViewController *{
        return [[AnotherViewController2 alloc] initWithNibName:nil bundle:nil];
    }];
    
    [self.animator presentFrom:MRFlipTransitionPresentingFromBottom completion:nil];
}
- (void)showAnotherController3:(id)sender
{
    if(stateview[2]==0){
        
        
        
        [[SoundManager sharedManager] playSound:@"tiger.mp3" looping:NO];
        stateview[2]++;
    }
    self.animator = [[MRFlipTransition alloc] initWithPresentingViewController:self presentBlock:^UIViewController *{
        return [[AnotherViewController3 alloc] initWithNibName:nil bundle:nil];
    }];
    
    [self.animator presentFrom:MRFlipTransitionPresentingFromBottom completion:nil];
}

- (void)showAnotherController4:(id)sender
{
    if(stateview[3]==0){
        
        
        
        [[SoundManager sharedManager] playSound:@"dragon1.mp3" looping:NO];
        stateview[3]++;
    }
    
    self.animator = [[MRFlipTransition alloc] initWithPresentingViewController:self presentBlock:^UIViewController *{
        return [[AnotherViewController4 alloc] initWithNibName:nil bundle:nil];
    }];
    
    [self.animator presentFrom:MRFlipTransitionPresentingFromBottom completion:nil];
}
- (void)showAnotherController5:(id)sender
{
    
    if(stateview[4]==0){
        
        
        
        [[SoundManager sharedManager] playSound:@"thunder.mp3" looping:NO];
        stateview[4]++;
    }
    
    self.animator = [[MRFlipTransition alloc] initWithPresentingViewController:self presentBlock:^UIViewController *{
        return [[AnotherViewController5 alloc] initWithNibName:nil bundle:nil];
    }];
    
    [self.animator presentFrom:MRFlipTransitionPresentingFromBottom completion:nil];
}

- (void)showoption:(id)sender
{
    
    [[SoundManager sharedManager] playSound:@"buttontouch.mp3" looping:NO];
    
    self.animator = [[MRFlipTransition alloc] initWithPresentingViewController:self presentBlock:^UIViewController *{
        return [[optionview alloc] initWithNibName:nil bundle:nil];
    }];
    
    [self.animator presentFrom:MRFlipTransitionPresentingFromBottom completion:nil];
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





- (void) viewWillUnload
{
    [super viewWillUnload];
    [self.fireEmitter removeFromSuperlayer];
    self.fireEmitter = nil;
    [self.smokeEmitter removeFromSuperlayer];
    self.smokeEmitter = nil;
}


- (BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIDeviceOrientationPortrait);
}


// ---------------------------------------------------------------------------------------------------------------
#pragma mark -
#pragma mark Interaction
// ---------------------------------------------------------------------------------------------------------------



- (void) setFireAmount:(float)zeroToOne

{
    
    // Update the fire properties
    [self.fireEmitter setValue:[NSNumber numberWithInt:(zeroToOne * 200)]
                    forKeyPath:@"emitterCells.fire.birthRate"];
    [self.fireEmitter setValue:[NSNumber numberWithFloat:zeroToOne]
                    forKeyPath:@"emitterCells.fire.lifetime"];
    [self.fireEmitter setValue:[NSNumber numberWithFloat:(zeroToOne * 0.35)]
                    forKeyPath:@"emitterCells.fire.lifetimeRange"];
    self.fireEmitter.emitterSize = CGSizeMake(50 * zeroToOne, 0);
    [self.smokeEmitter setValue:[NSNumber numberWithInt:zeroToOne * 8]
                     forKeyPath:@"emitterCells.smoke.lifetime"];
    [self.smokeEmitter setValue:(id)[[UIColor colorWithRed:1 green:1 blue:1 alpha:zeroToOne * 0.3] CGColor]
                     forKeyPath:@"emitterCells.smoke.color"];
    
    
    
}

////////////////////////////////////////////////////////////////////////////////////////////////

- (void)submit:(id)sender
{
    AppDelegate *myDelegate = [[UIApplication sharedApplication] delegate];
    myDelegate.plus = &(plus1);
    sleep(0.45);
    [[SoundManager sharedManager] playSound:@"buttontouch.mp3" looping:NO];
    self.animator = [[MRFlipTransition alloc] initWithPresentingViewController:self presentBlock:^UIViewController *{
        return [[scoreview alloc] initWithNibName:nil bundle:nil];
    }];
    [self.animator presentFrom:MRFlipTransitionPresentingFromBottom completion:nil];
    
}


//submit page  circleselect
////////////////////////////////////////////////////////////////////////////


- (IBAction)circleselect11:(UIButton *)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    
    dna2.alpha = 1;
    dna7.alpha = 1;
    circle10.alpha = 1;
    
    daddy.alpha= 0.35;
    circle11.alpha = 0.8;
    circle21.alpha = 0;
    circle31.alpha = 0;
    circle41.alpha = 0;
    bsubmit.alpha = 0;
    [UIView commitAnimations];
    
    
}


- (IBAction)circleselect10:(UIButton *)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    
    dna2.alpha = 0;
    dna7.alpha = 0;
    circle10.alpha = 0;
    
    daddy.alpha = 1;
    circle11.alpha = 1;
    circle21.alpha = 1;
    circle31.alpha = 1;
    circle41.alpha = 1;
    bsubmit.alpha = 1;
    
    
    [UIView commitAnimations];
}


- (IBAction)circleselect21:(UIButton *)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    
    daddy.alpha= 0.35;
    dna8.alpha = 1;
    dna9.alpha = 1;
    dna10.alpha = 1;
    
    circle11.alpha = 0;
    circle21.alpha = 0.8;
    circle20.alpha = 1;
    circle31.alpha = 0;
    circle41.alpha = 0;
    bsubmit.alpha = 0;
    
    [UIView commitAnimations];
}

- (IBAction)circleselect20:(UIButton *)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    
    daddy.alpha= 1;
    dna8.alpha = 0;
    dna9.alpha = 0;
    dna10.alpha = 0;
    
    circle11.alpha = 1;
    circle21.alpha = 1;
    circle20.alpha = 0;
    circle31.alpha = 1;
    circle41.alpha = 1;
    bsubmit.alpha = 1;
    
    [UIView commitAnimations];
}


- (IBAction)circleselect31:(UIButton *)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    
    daddy.alpha= 0.35;
    dna6.alpha = 1;
    dna4.alpha = 1;
    dna1.alpha = 1;
    
    circle11.alpha = 0;
    circle21.alpha = 0;
    circle31.alpha = 0.8;
    circle30.alpha = 1;
    circle41.alpha = 0;
    bsubmit.alpha = 0;
    
    [UIView commitAnimations];
}

- (IBAction)circleselect30:(UIButton *)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    
    daddy.alpha= 1;
    dna6.alpha = 0;
    dna4.alpha = 0;
    dna1.alpha = 0;
    
    circle11.alpha = 1;
    circle21.alpha = 1;
    circle31.alpha = 01;
    circle30.alpha = 0;
    circle41.alpha = 1;
    bsubmit.alpha = 1;
    
    [UIView commitAnimations];
}


- (IBAction)circleselect41:(UIButton *)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    
    daddy.alpha= 0.35;
    dna5.alpha = 1;
    dna3.alpha = 1;
    
    circle11.alpha = 0;
    circle21.alpha = 0;
    circle31.alpha = 0;
    circle41.alpha = 0.8;
    circle40.alpha = 1;
    bsubmit.alpha = 0;
    
    [UIView commitAnimations];
}

- (IBAction)circleselect40:(UIButton *)sender
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    
    daddy.alpha= 1;
    dna5.alpha = 0;
    dna3.alpha = 0;
    
    circle11.alpha = 1;
    circle21.alpha = 1;
    circle31.alpha = 1;
    circle41.alpha = 1;
    circle40.alpha = 0;
    bsubmit.alpha = 1;
    
    [UIView commitAnimations];
}




/////////DNA SELECT
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


- (IBAction)Dnaselect1:(UIButton *)sender
{
    if (state[0]==0)
    {
        
        
        if((state[0]+state[3]+state[5])<1){
            
            
            [sender setBackgroundImage:[UIImage imageNamed:@"bluea"] forState:UIControlStateNormal];
            state[0]++;
        }
        
    }
    
    else if(state[0]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"blueb"] forState:UIControlStateNormal];
        state[0]--;
        
    }
    
    
    
    
    
}


- (IBAction)Dnaselect2:(UIButton *)sender
{
    if (state[1]==0)
    {
        
        
        if((state[1]+state[6])<1){
            
            
            [sender setBackgroundImage:[UIImage imageNamed:@"2_on"] forState:UIControlStateNormal];
            state[1]++;
            plus1++;
        }
        
    }
    
    else if(state[1]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"2_off"] forState:UIControlStateNormal];
        state[1]--;
        plus1--;
    }
    
}


- (IBAction)Dnaselect3:(UIButton *)sender
{
    if (state[2]==0)
    {
        
        
        if((state[2]+state[4])<1){
            [sender setBackgroundImage:[UIImage imageNamed:@"3_on"] forState:UIControlStateNormal];
            state[2]++;
        }
        
    }
    
    else if(state[2]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"3_off"] forState:UIControlStateNormal];
        state[2]--;
    }
}


- (IBAction)Dnaselect4:(UIButton *)sender
{
    
    if (state[3]==0)
    {
        
        
        if((state[0]+state[3]+state[5])<1){
            
            
            [sender setBackgroundImage:[UIImage imageNamed:@"4_on"] forState:UIControlStateNormal];
            state[3]++;
            
        }
        
    }
    
    else if(state[3]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"4_off"] forState:UIControlStateNormal];
        state[3]--;
        
    }
    
}


- (IBAction)Dnaselect5:(UIButton *)sender
{
    if (state[4]==0)
    {
        
        
        if((state[2]+state[4])<1){
            
            
            [sender setBackgroundImage:[UIImage imageNamed:@"5_on"] forState:UIControlStateNormal];
            state[4]++;
            plus1++;
        }
        
    }
    
    else if(state[4]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"5_off"] forState:UIControlStateNormal];
        state[4]--;
        plus1--;
    }
}


- (IBAction)Dnaselect6:(UIButton *)sender
{
    if (state[5]==0)
    {
        
        
        if((state[0]+state[3]+state[5])<1){
            
            
            [sender setBackgroundImage:[UIImage imageNamed:@"6_on"] forState:UIControlStateNormal];
            state[5]++;
            plus1++;
        }
        
    }
    
    else if(state[5]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"6_off"] forState:UIControlStateNormal];
        state[5]--;
        plus1--;
    }
}


- (IBAction)Dnaselect7:(UIButton *)sender
{
    if (state[6]==0)
    {
        
        
        if((state[1]+state[6])<1){
            
            
            [sender setBackgroundImage:[UIImage imageNamed:@"7_on"] forState:UIControlStateNormal];
            state[6]++;
            
        }
        
    }
    
    else if(state[6]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"7_off"] forState:UIControlStateNormal];
        state[6]--;
        
    }
}


- (IBAction)Dnaselect8:(UIButton *)sender
{
    if (state[7]==0)
    {
        
        
        if((state[7]+state[8]+state[9])<1){
            
            
            [sender setBackgroundImage:[UIImage imageNamed:@"8_on"] forState:UIControlStateNormal];
            state[7]++;
            plus1++;
        }
        
    }
    
    else if(state[7]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"8_off"] forState:UIControlStateNormal];
        state[7]--;
        plus1--;
    }
}


- (IBAction)Dnaselect9:(UIButton *)sender
{
    
    if (state[8]==0)
    {
        
        
        if((state[7]+state[8]+state[9])<1){
            
            
            [sender setBackgroundImage:[UIImage imageNamed:@"9_on"] forState:UIControlStateNormal];
            state[8]++;
            
        }
        
    }
    
    else if(state[8]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"9_off"] forState:UIControlStateNormal];
        state[8]--;
    }
}


- (IBAction)Dnaselect10:(UIButton *)sender
{
    if (state[9]==0)
    {
        
        
        if((state[7]+state[8]+state[9])<1){
            
            
            [sender setBackgroundImage:[UIImage imageNamed:@"10_on"] forState:UIControlStateNormal];
            state[9]++;
            
        }
        
    }
    
    else if(state[9]==1)
    {
        
        [sender setBackgroundImage:[UIImage imageNamed:@"10_off"] forState:UIControlStateNormal];
        state[9]--;
    }
    
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////






//introview
- (void)showIntroWithCrossDissolve {
    EAIntroPage *page1 = [EAIntroPage page];
    page1.title = @"Legend";
    page1.desc = @"Long, long ago, a dragon had five children. One day, the old dragon disappeared mysteriously and left the five offspring alone,In order to find their father, we are on the tour…";
    page1.bgImage = [UIImage imageNamed:@"introbg"];
    page1.titleImage21 = [UIImage imageNamed:@"father_head"];
    page1.titleImage22 = [UIImage imageNamed:@"son1_head"];
    page1.titleImage23 = [UIImage imageNamed:@"son2_head"];
    page1.titleImage24 = [UIImage imageNamed:@"son3_head"];
    page1.titleImage25 = [UIImage imageNamed:@"son4_head"];
    page1.titleImage26 = [UIImage imageNamed:@"son5_head"];
    
    
    
    
    EAIntroPage *page2 = [EAIntroPage page];
    page2.title = @"How to play";
    page2.desc = @"Observe the color of various body parts and remember them in order to select them. Features can also decide the color of the gene";
    page2.bgImage = [UIImage imageNamed:@"introbg"];
    page2.titleImage = [UIImage imageNamed:@"fatheroutline"];
    page2.titleImage12 = [UIImage imageNamed:@"circle1"];
    page2.titleImage13 = [UIImage imageNamed:@"3_on"];
    
    
    
    
    
    //    EAIntroPage *page2 = [EAIntroPage page];
    //    page2.title = @"This is page 2";
    //    page2.desc = @"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore.";
    //    page2.bgImage = [UIImage imageNamed:@"2"];
    //    page2.titleImage = [UIImage imageNamed:@"supportcat"];
    
    
    EAIntroPage *page3 = [EAIntroPage page];
    page3.title = @"How to play";
    page3.desc = @"Select the gene owned by more than half of the son";
    page3.bgImage = [UIImage imageNamed:@"introbg"];
    page3.titleImage31 = [UIImage imageNamed:@"introsubmit"];
    page3.titleImage32 = [UIImage imageNamed:@"intro2_on"];
    page3.titleImage33 = [UIImage imageNamed:@"intro9_on"];
    
    
    
    
    
    
    EAIntroView *intro = [[EAIntroView alloc] initWithFrame:self.view.bounds andPages:@[page1,page2,page3]];
    [intro setDelegate:self];
    [intro showInView:self.view animateDuration:0.0];
}


///////////////////////////////////////////////////////////////////////////////




@end
