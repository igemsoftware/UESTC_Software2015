//
//  EAIntroPage.h
//  EAIntroView
//
//  Copyright (c) 2013 Evgeny Aleksandrov.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface EAIntroPage : NSObject

// title image Y position - from top of the screen
// title and description labels Y position - from bottom of the screen
@property (nonatomic, retain) UIImage *bgImage;
@property (nonatomic, retain) UIImage *titleImage;
@property (nonatomic, retain) UIImage *titleImage12;
@property (nonatomic, retain) UIImage *titleImage13;

@property (nonatomic, retain) UIImage *titleImage21;
@property (nonatomic, retain) UIImage *titleImage22;
@property (nonatomic, retain) UIImage *titleImage23;
@property (nonatomic, retain) UIImage *titleImage24;
@property (nonatomic, retain) UIImage *titleImage25;
@property (nonatomic, retain) UIImage *titleImage26;
@property (nonatomic, retain) UIImage *titleImage31;
@property (nonatomic, retain) UIImage *titleImage32;
@property (nonatomic, retain) UIImage *titleImage33;

@property (nonatomic, retain) UIImage *titleImage41;
@property (nonatomic, retain) UIImage *titleImage42;
@property (nonatomic, retain) UIImage *titleImage43;


@property (nonatomic, assign) CGFloat imgPositionY;
@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) UIFont *titleFont;
@property (nonatomic, retain) UIColor *titleColor;
@property (nonatomic, assign) CGFloat titlePositionY;
@property (nonatomic, retain) NSString *desc;
@property (nonatomic, retain) UIFont *descFont;
@property (nonatomic, retain) UIColor *descColor;
@property (nonatomic, assign) CGFloat descPositionY;
@property (nonatomic, retain) UIImage *son1small;
@property (nonatomic, retain) UIImageView *son2small;
@property (nonatomic, retain) UIImageView *son3small;
@property (nonatomic, retain) UIImageView *son4small;
@property (nonatomic, retain) UIImageView *son5small;


// if customView is set - all other properties are ignored
@property (nonatomic, retain) UIView *customView;

+ (EAIntroPage *)page;
+ (EAIntroPage *)pageWithCustomView:(UIView *)customV;

@end
