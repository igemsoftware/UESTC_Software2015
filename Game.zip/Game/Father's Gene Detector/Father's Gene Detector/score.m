//
//  AnotherViewController.m
//  FlipDemo
//
//  Created by kimjunhyuk on 12/7/14.
//  Copyright (c) 2015 Kimjunhyuk. All rights reserved.
//

#import "score.h"
#import "optionview.h"
#import "MRFlipTransition.h"
#import "EAIntroView.h"
#import "AppDelegate.h"


@interface scoreview()

@end

@implementation scoreview






- (void)viewDidLoad
{

         [super viewDidLoad];
    
    
    

    self.view.backgroundColor =  [UIColor colorWithPatternImage: [UIImage imageNamed:@"shadow.png"]];
    
    AppDelegate *myDelegate = [[UIApplication sharedApplication] delegate];
    plus2 = *(myDelegate.plus);

    if(plus2 == 4)
    {
        
        
        
        
        UIImageView *fullmarks = [[UIImageView alloc] initWithFrame:CGRectMake(-50,0,500,500)];
        [fullmarks setImage:[UIImage imageNamed:@"4long.png"]];
        [self.view addSubview:fullmarks];
        
        [UIView animateWithDuration:1000.0 delay:0 usingSpringWithDamping:0 initialSpringVelocity:0.0007 options:UIViewAnimationOptionCurveLinear animations:^{
            fullmarks.center=CGPointMake(195,297);
        } completion:nil];
        
        
        UILabel* text0 = [[UILabel alloc] initWithFrame:CGRectMake(35, 500, 300, 150)];
        [text0 setNumberOfLines:0];
        text0.text = @"Congradulations! The dragon has come!";
        text0.font = [UIFont fontWithName:@"papyrus" size:25.0];
        text0.textColor = [UIColor whiteColor];
        [self.view addSubview:text0];
        
    }
    else if(plus2 == 3)
    {   UIImageView *fullmarks = [[UIImageView alloc] initWithFrame:CGRectMake(-50,0,500,500)];
        [fullmarks setImage:[UIImage imageNamed:@"3long.png"]];
        [self.view addSubview:fullmarks];
        
        [UIView animateWithDuration:1000.0 delay:0 usingSpringWithDamping:0 initialSpringVelocity:0.0007 options:UIViewAnimationOptionCurveLinear animations:^{
            fullmarks.center=CGPointMake(195,297);
        } completion:nil];
        
        
        
        UILabel* text0 = [[UILabel alloc] initWithFrame:CGRectMake(35, 500, 300, 150)];
        [text0 setNumberOfLines:0];
        text0.text = @"Be carefull, only one right gene is missed!";
        text0.font = [UIFont fontWithName:@"papyrus" size:25.0];
        text0.textColor = [UIColor whiteColor];
        [self.view addSubview:text0];
    }
    else if(plus2 == 2)
    {   UIImageView *fullmarks = [[UIImageView alloc] initWithFrame:CGRectMake(-50,0,500,500)];
        [fullmarks setImage:[UIImage imageNamed:@"2long.png"]];
        [self.view addSubview:fullmarks];
        
        [UIView animateWithDuration:1000.0 delay:0 usingSpringWithDamping:0 initialSpringVelocity:0.0007 options:UIViewAnimationOptionCurveLinear animations:^{
            fullmarks.center=CGPointMake(195,297);
        } completion:nil];
        
        
        
        UILabel* text0 = [[UILabel alloc] initWithFrame:CGRectMake(35, 500, 300, 150)];
        [text0 setNumberOfLines:0];
        text0.text = @"There are still 2 right genes to be chosen.";
        text0.font = [UIFont fontWithName:@"papyrus" size:25.0];
        text0.textColor = [UIColor whiteColor];
        [self.view addSubview:text0];
    }
    else if(plus2 == 1)
    {
        UIImageView *fullmarks = [[UIImageView alloc] initWithFrame:CGRectMake(-50,0,500,500)];
        [fullmarks setImage:[UIImage imageNamed:@"1long.png"]];
        [self.view addSubview:fullmarks];
        
        [UIView animateWithDuration:1000.0 delay:0 usingSpringWithDamping:0 initialSpringVelocity:0.0007 options:UIViewAnimationOptionCurveLinear animations:^{
            fullmarks.center=CGPointMake(195,297);
        } completion:nil];
        
        
        UILabel* text0 = [[UILabel alloc] initWithFrame:CGRectMake(35, 500, 300, 150)];
        [text0 setNumberOfLines:0];
        text0.text = @"There are still 3 right genes to be chosen.";
        text0.font = [UIFont fontWithName:@"papyrus" size:25.0];
        text0.textColor = [UIColor whiteColor];
        [self.view addSubview:text0];
        
    }
    else if(plus2 == 0)
    {
        
        
        UIImageView *fullmarks = [[UIImageView alloc] initWithFrame:CGRectMake(-50,0,500,500)];
        [fullmarks setImage:[UIImage imageNamed:@"0long.png"]];
        [self.view addSubview:fullmarks];
        
        [UIView animateWithDuration:1000.0 delay:0 usingSpringWithDamping:0 initialSpringVelocity:0.0007 options:UIViewAnimationOptionCurveLinear animations:^{
            fullmarks.center=CGPointMake(195,297);
        } completion:nil];
        
        
        UILabel* text0 = [[UILabel alloc] initWithFrame:CGRectMake(35, 500, 300, 150)];
        [text0 setNumberOfLines:0];
        text0.text = @"Sorry, none of what you choose is the right one!";
        text0.font = [UIFont fontWithName:@"papyrus" size:25.0];
        text0.textColor = [UIColor whiteColor];
        [self.view addSubview:text0];
    }
    
    [AppDelegate storyBoradAutoLay:self.view];
 
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [(MRFlipTransition *)self.transitioningDelegate updateContentSnapshot:self.view afterScreenUpdate:YES];
}

- (void)flyAway:(id)sender
{
     [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
}


//点击周围就退出
- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [[event allTouches] anyObject];
   CGPoint touchPoint = [touch locationInView:self.view];
    [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
    
}

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [[event allTouches] anyObject];
   CGPoint touchPoint = [touch locationInView:self.view];
    [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
}













@end
