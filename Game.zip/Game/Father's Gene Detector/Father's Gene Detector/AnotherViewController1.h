//
//  AnotherViewController.h
//  FlipDemo
//
//  Created by kimjunhyuk on 12/7/14.
//  Copyright (c) 2015 Kimjunhyuk. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CUSFlashLabel.h"
#import "SoundManager.h"

@interface AnotherViewController1 : UIViewController
{
    int state;
    int refresh;
    UIButton *son1;
    CUSFlashLabel *label;
    CUSFlashLabel *label2;
}
@end
