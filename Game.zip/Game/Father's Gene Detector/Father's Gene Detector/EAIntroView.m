//
//  EAIntroView.m
//  EAIntroView
//
//  Copyright (c) 2013 Evgeny Aleksandrov.
//

#import "EAIntroView.h"
#import "AppDelegate.h"

#define DEFAULT_BACKGROUND_COLOR [UIColor blackColor]

@interface EAIntroView() {
    NSMutableArray *pageViews;
    NSInteger LastPageIndex;
}

@end

@implementation EAIntroView

#pragma mark - Init

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        pageViews = [[NSMutableArray alloc] init];
        self.swipeToExit = YES;
        self.hideOffscreenPages = YES;
        self.titleViewY = 20.0f;
        self.pageControlY = 60.0f;
        [self buildUIWithFrame:frame];
        [self setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        pageViews = [[NSMutableArray alloc] init];
        self.swipeToExit = YES;
        self.hideOffscreenPages = YES;
        self.titleViewY = 20.0f;
        self.pageControlY = 60.0f;
        [self buildUIWithFrame:self.frame];
        [self setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame andPages:(NSArray *)pagesArray {
    self = [super initWithFrame:frame];
    if (self) {
        pageViews = [[NSMutableArray alloc] init];
        self.swipeToExit = YES;
        self.hideOffscreenPages = YES;
        self.titleViewY = 20.0f;
        self.pageControlY = 60.0f;
        _pages = [pagesArray copy];
        [self buildUIWithFrame:frame];
        [self setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
    }
    return self;
}

#pragma mark - UI building

- (void)buildUIWithFrame:(CGRect)frame {
    self.backgroundColor = DEFAULT_BACKGROUND_COLOR;
    
    [self buildBackgroundImage];
    [self buildScrollViewWithFrame:frame];
    
    [self buildFooterView];
    
    [self.bgImageView setAutoresizingMask:UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight];
    [self.pageControl setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [self.skipButton setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
}

- (void)buildBackgroundImage {
    self.bgImageView = [[UIImageView alloc] initWithFrame:self.frame];
    self.bgImageView.backgroundColor = [UIColor clearColor];
    self.bgImageView.contentMode = UIViewContentModeScaleToFill;
    self.bgImageView.autoresizesSubviews = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.bgImageView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    [self addSubview:self.bgImageView];
    
    self.pageBgBack = [[UIImageView alloc] initWithFrame:self.frame];
    self.pageBgBack.backgroundColor = [UIColor clearColor];
    self.pageBgBack.contentMode = UIViewContentModeScaleToFill;
    self.pageBgBack.autoresizesSubviews = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.pageBgBack.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.pageBgBack.alpha = 0;
    [self addSubview:self.pageBgBack];
    
    self.pageBgFront = [[UIImageView alloc] initWithFrame:self.frame];
    self.pageBgFront.backgroundColor = [UIColor clearColor];
    self.pageBgFront.contentMode = UIViewContentModeScaleToFill;
    self.pageBgFront.autoresizesSubviews = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.pageBgFront.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.pageBgFront.alpha = 0;
    [self addSubview:self.pageBgFront];
}

- (void)buildScrollViewWithFrame:(CGRect)frame {
    
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.frame];
    
    self.scrollView.pagingEnabled = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.delegate = self;
    
    self.scrollView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    
    //A running x-coordinate. This grows for every page
    CGFloat contentXIndex = 0;
    for (int idx = 0; idx < _pages.count; idx++) {
        [pageViews addObject:[self viewForPage:_pages[idx] atXIndex:&contentXIndex]];
        [self.scrollView addSubview:pageViews[idx]];
    }
    
    [self makePanelVisibleAtIndex:0];
    
    if (self.swipeToExit) {
        [self appendCloseViewAtXIndex:&contentXIndex];
    }
    
    self.scrollView.contentSize = CGSizeMake(contentXIndex, self.scrollView.frame.size.height);
    [self addSubview:self.scrollView];
    
    [self.pageBgBack setAlpha:0];
    [self.pageBgBack setImage:[self bgForPage:1]];
    [self.pageBgFront setAlpha:1];
    [self.pageBgFront setImage:[self bgForPage:0]];
}

- (UIView *)viewForPage:(EAIntroPage *)page atXIndex:(CGFloat *)xIndex {
    
    
    
    UIView *pageView = [[UIView alloc] initWithFrame:CGRectMake(*xIndex, 0, self.scrollView.frame.size.width, self.scrollView.frame.size.height)];
    
    
    *xIndex += self.scrollView.frame.size.width;
    if(page.customView) {
        [pageView addSubview:page.customView];
        return pageView;
    }
    
    if(page.titleImage)
    {
        UIImageView *titleImageView = [[UIImageView alloc] initWithImage:page.titleImage];
        CGRect rect1 = titleImageView.frame;
        titleImageView.frame = CGRectMake(-15,page.imgPositionY-90, 400, 400);
        titleImageView.alpha = 1;
        [pageView addSubview:titleImageView];
    }
    
    if(page.titleImage12)
    {
        UIImageView *titleImageView12 = [[UIImageView alloc] initWithImage:page.titleImage12];
        CGRect rect1 = titleImageView12.frame;
        titleImageView12.frame = CGRectMake(240,page.imgPositionY, 50, 50);
        titleImageView12.alpha = 1;
        [pageView addSubview:titleImageView12];
    }
    
    if(page.titleImage13) {
        
        UIImageView *titleImageView13 = [[UIImageView alloc] initWithImage:page.titleImage13];
        CGRect rect1 = titleImageView13.frame;
        titleImageView13.frame = CGRectMake(250,page.imgPositionY-30, 100, 40);
        titleImageView13.alpha = 1;
        [pageView addSubview:titleImageView13];

        [AppDelegate storyBoradAutoLay:pageView];

        titleImageView13.transform = CGAffineTransformRotate(titleImageView13.transform, M_PI_4*0.4);

       
    }

    
    if(page.titleImage22)
    {
        UIImageView *titleImageView22 = [[UIImageView alloc] initWithImage:page.titleImage22];
        CGRect rect1 = titleImageView22.frame;
        titleImageView22.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2+50,page.imgPositionY, 73, 73);
        titleImageView22.alpha = 0;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:3.0];
        titleImageView22.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2+50,page.imgPositionY-90, 73, 73);
        titleImageView22.alpha = 1;
        [UIView commitAnimations];
        [pageView addSubview:titleImageView22];
    }
    
    if(page.titleImage23)
    {
        UIImageView *titleImageView23 = [[UIImageView alloc] initWithImage:page.titleImage23];
        CGRect rect1 = titleImageView23.frame;
        titleImageView23.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2+50,page.imgPositionY, 73, 73);
        titleImageView23.alpha = 0;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:3.0];
        titleImageView23.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2-60,page.imgPositionY-10, 73, 73);
        titleImageView23.alpha = 1;
        [UIView commitAnimations];
        [pageView addSubview:titleImageView23];
    }
    
    if(page.titleImage24)
    {
        UIImageView *titleImageView24 = [[UIImageView alloc] initWithImage:page.titleImage24];
        CGRect rect1 = titleImageView24.frame;
        titleImageView24.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2+50,page.imgPositionY, 73, 73);
        titleImageView24.alpha = 0;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:3.0];
        titleImageView24.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2+160,page.imgPositionY-10, 73, 73);
        titleImageView24.alpha = 1;
        [UIView commitAnimations];
        [pageView addSubview:titleImageView24];
    }
    
    if(page.titleImage25)
    {
        UIImageView *titleImageView25 = [[UIImageView alloc] initWithImage:page.titleImage25];
        CGRect rect1 = titleImageView25.frame;
        titleImageView25.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2+50,page.imgPositionY, 73, 73);
        titleImageView25.alpha = 0;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:3.0];
        titleImageView25.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2-40,page.imgPositionY+125, 73, 73);
        titleImageView25.alpha = 1;
        [UIView commitAnimations];
        [pageView addSubview:titleImageView25];
    }
    
    if(page.titleImage26)
    {
        UIImageView *titleImageView26 = [[UIImageView alloc] initWithImage:page.titleImage26];
        CGRect rect1 = titleImageView26.frame;
        titleImageView26.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2+50,page.imgPositionY, 73, 73);
        titleImageView26.alpha = 0;
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:3.0];
        titleImageView26.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2+130,page.imgPositionY+125, 73, 73);
        titleImageView26.alpha = 1;
        [UIView commitAnimations];
        [pageView addSubview:titleImageView26];
    }
    
    if(page.titleImage21) {
        UIImageView *titleImageView21 = [[UIImageView alloc] initWithImage:page.titleImage21];
        CGRect rect1 = titleImageView21.frame;
        titleImageView21.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2+18,page.imgPositionY,140, 140);
        titleImageView21.alpha = 1;

//        rect1.origin.x = 150;
//        rect1.origin.y = page.imgPositionY;

        

//        [UIView beginAnimations:nil context:nil];
//        [UIView setAnimationDuration:7.0];
//        titleImageView21.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2,page.imgPositionY, 150, 150);
//        titleImageView21.alpha = 1;
//        [UIView commitAnimations];
        [pageView addSubview:titleImageView21];
    }
    
    
    
    
    if(page.titleImage31)
    {
        UIImageView *titleImageView31 = [[UIImageView alloc] initWithImage:page.titleImage31];
        //        CGRect rect1 = titleImageView31.frame;
        titleImageView31.frame = CGRectMake(210,page.imgPositionY-50, 244.6, 342);
        titleImageView31.alpha = 1;
        titleImageView31.transform = CGAffineTransformRotate(titleImageView31.transform, M_PI_4*0.4);
        
        [pageView addSubview:titleImageView31];
        
    }
    
    if(page.titleImage32)
    {
        UIImageView *titleImageView32 = [[UIImageView alloc] initWithImage:page.titleImage32];
        CGRect rect1 = titleImageView32.frame;
        titleImageView32.frame = CGRectMake(60, page.imgPositionY+15, 63, 31.5);
        titleImageView32.alpha = 1;
        //        [UIView beginAnimations:nil context:nil];
        //        [UIView setAnimationDuration:10.0];
        //        titleImageView32.frame = CGRectMake(200, page.imgPositionY+105, 84, 42);
        //        titleImageView32.alpha = 1;
        //        [UIView commitAnimations];
        [pageView addSubview:titleImageView32];
        
        //        self.girlImageView.transform = CGAffineTransformMakeTranslation((kScreenWidth + 100.0f) * currentX / kScreenWidth, 0);
        //        self.label_page1_2.transform = CGAffineTransformMakeTranslation(- 200 * currentX / kScreenWidth, 0);
        
    }
    
    if(page.titleImage33)
    {
        UIImageView *titleImageView33 = [[UIImageView alloc] initWithImage:page.titleImage33];
        CGRect rect1 = titleImageView33.frame;
        titleImageView33.frame = CGRectMake(60, page.imgPositionY+120, 63, 31.5);
        titleImageView33.alpha = 1;
        //        [UIView beginAnimations:nil context:nil];
        //        [UIView setAnimationDuration:10.0];
        //        titleImageView33.frame = CGRectMake(200,page.imgPositionY+135, 84, 42);
        //        titleImageView33.alpha = 1;
        //        [UIView commitAnimations];
        [pageView addSubview:titleImageView33];
    }

    
    
//    if(page.titleImage41)
//    {
//        UIImageView *titleImageView41 = [[UIImageView alloc] initWithImage:page.titleImage41];
////        CGRect rect1 = titleImageView31.frame;
//        titleImageView41.frame = CGRectMake(210,page.imgPositionY-50, 244.6, 342);
//        titleImageView41.alpha = 1;
//        titleImageView41.transform = CGAffineTransformRotate(titleImageView41.transform, M_PI_4*0.4);
//
//        [pageView addSubview:titleImageView41];
//
//    }
//
//    if(page.titleImage42)
//    {
//        UIImageView *titleImageView42 = [[UIImageView alloc] initWithImage:page.titleImage42];
//        CGRect rect1 = titleImageView42.frame;
//        titleImageView42.frame = CGRectMake(60, page.imgPositionY+15, 63, 31.5);
//        titleImageView42.alpha = 1;
////        [UIView beginAnimations:nil context:nil];
////        [UIView setAnimationDuration:10.0];
////        titleImageView32.frame = CGRectMake(200, page.imgPositionY+105, 84, 42);
////        titleImageView32.alpha = 1;
////        [UIView commitAnimations];
//        [pageView addSubview:titleImageView42];
//        
////        self.girlImageView.transform = CGAffineTransformMakeTranslation((kScreenWidth + 100.0f) * currentX / kScreenWidth, 0);
////        self.label_page1_2.transform = CGAffineTransformMakeTranslation(- 200 * currentX / kScreenWidth, 0);
//
//    }
//
//    if(page.titleImage43)
//    {
//        UIImageView *titleImageView43 = [[UIImageView alloc] initWithImage:page.titleImage43];
//        CGRect rect1 = titleImageView43.frame;
//        titleImageView43.frame = CGRectMake(60, page.imgPositionY+120, 63, 31.5);
//        titleImageView43.alpha = 1;
////        [UIView beginAnimations:nil context:nil];
////        [UIView setAnimationDuration:10.0];
////        titleImageView33.frame = CGRectMake(200,page.imgPositionY+135, 84, 42);
////        titleImageView33.alpha = 1;
////        [UIView commitAnimations];
//        [pageView addSubview:titleImageView43];
//    }

    
    
    
    
    if([page.title length]) {
        CGFloat titleHeight;
        
        if ([page.title respondsToSelector:@selector(boundingRectWithSize:options:attributes:context:)]) {
            NSAttributedString *attributedText = [[NSAttributedString alloc] initWithString:page.title attributes:@{ NSFontAttributeName: page.titleFont }];
            CGRect rect = [attributedText boundingRectWithSize:(CGSize){self.scrollView.frame.size.width - 20, CGFLOAT_MAX} options:NSStringDrawingUsesLineFragmentOrigin context:nil];
            titleHeight = ceilf(rect.size.height);
        } else {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
            titleHeight = [page.title sizeWithFont:page.titleFont constrainedToSize:CGSizeMake(self.scrollView.frame.size.width - 20, CGFLOAT_MAX) lineBreakMode:NSLineBreakByWordWrapping].height;
#pragma clang diagnostic pop
        }
        
        CGRect titleLabelFrame = CGRectMake(10, self.frame.size.height - page.titlePositionY, self.scrollView.frame.size.width - 20, titleHeight);
        
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:titleLabelFrame];
        titleLabel.text = page.title;
        titleLabel.font = page.titleFont;
        titleLabel.textColor = page.titleColor;
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        [pageView addSubview:titleLabel];
    }
    
    if([page.desc length]) {
        CGRect descLabelFrame = CGRectMake(0, self.frame.size.height - page.descPositionY, self.scrollView.frame.size.width, 500);
        
        UITextView *descLabel = [[UITextView alloc] initWithFrame:descLabelFrame];
        descLabel.text = page.desc;
        descLabel.scrollEnabled = NO;
        descLabel.font = page.descFont;
        descLabel.textColor = page.descColor;
        descLabel.backgroundColor = [UIColor clearColor];
        descLabel.textAlignment = NSTextAlignmentCenter;
        descLabel.userInteractionEnabled = NO;
        //[descLabel sizeToFit];
        [pageView addSubview:descLabel];
        
    }
    

    return pageView;
}

- (void)appendCloseViewAtXIndex:(CGFloat*)xIndex {
    UIView *closeView = [[UIView alloc] initWithFrame:CGRectMake(*xIndex, 0, self.frame.size.width, self.frame.size.height)];
    closeView.tag = 124;
    [self.scrollView addSubview:closeView];
    
    *xIndex += self.scrollView.frame.size.width;
}

- (void)removeCloseViewAtXIndex:(CGFloat*)xIndex {
    UIView *closeView = [self.scrollView viewWithTag:124];
    if(closeView) {
        [closeView removeFromSuperview];
    }
    
    *xIndex -= self.scrollView.frame.size.width;
}

- (void)buildFooterView {
    self.pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, self.frame.size.height - self.pageControlY, self.frame.size.width, 20)];
    [self.pageControl setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [self.pageControl addTarget:self action:@selector(showPanelAtPageControl) forControlEvents:UIControlEventValueChanged];
    self.pageControl.numberOfPages = _pages.count;
    [self addSubview:self.pageControl];
    
    self.skipButton = [[UIButton alloc] initWithFrame:CGRectMake(self.scrollView.frame.size.width - 80, self.pageControl.frame.origin.y, 80, self.pageControl.frame.size.height)];
    
    [self.skipButton setAutoresizingMask: UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin];
    [self.skipButton setTitle:NSLocalizedString(@"Skip", nil) forState:UIControlStateNormal];
    [self.skipButton addTarget:self action:@selector(skipIntroduction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.skipButton];
}

#pragma mark - UIScrollView Delegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    self.currentPageIndex = scrollView.contentOffset.x/self.scrollView.frame.size.width;
    
    if (self.currentPageIndex == (pageViews.count)) {
        if ([(id)self.delegate respondsToSelector:@selector(introDidFinish)]) {
            [self.delegate introDidFinish];
        }
    } else {
        LastPageIndex = self.pageControl.currentPage;
        self.pageControl.currentPage = self.currentPageIndex;
        
        [self makePanelVisibleAtIndex:(NSInteger)self.currentPageIndex];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    float offset = scrollView.contentOffset.x / self.scrollView.frame.size.width;
    CGFloat currentX = scrollView.contentOffset.x;
    NSInteger page = (int)(offset);
    
    if (page == (pageViews.count - 1) && self.swipeToExit) {
        self.alpha = ((self.scrollView.frame.size.width*pageViews.count)-self.scrollView.contentOffset.x)/self.scrollView.frame.size.width;
    } else {
        [self crossDissolveForOffset:offset];
    }
//    if (currentX >= self.scrollView.frame.size.width)
//    {
//        EAIntroPage *page2 = [EAIntroPage page];
//        page2.titleImage22 = [UIImage imageNamed:@"son1_head"];
//        UIImageView *titleImageView22 = [[UIImageView alloc] initWithImage:page.titleImage22];
//
//        CGRect rect1 = titleImageView22.frame;
//        titleImageView22.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2,page.imgPositionY, 73, 73);
//        titleImageView22.alpha = 0;
//        [UIView beginAnimations:nil context:nil];
//        [UIView setAnimationDuration:3.0];
//        titleImageView22.frame = CGRectMake((self.scrollView.frame.size.width - rect1.size.width)/2,page.imgPositionY-70, 73, 73);
//        titleImageView22.alpha = 1;
//        [UIView commitAnimations];
//        [pageView addSubview:titleImageView22];
//
//        titleImageView22.transform = CGAffineTransformMakeTranslation((self.scrollView.frame.size.width + 100.0f) * currentX / self.scrollView.frame.size.width, 0);
//        self.label_page1_2.transform = CGAffineTransformMakeTranslation(- 200 * currentX / kScreenWidth, 0);
//    }
}

- (void)crossDissolveForOffset:(float)offset {
    NSInteger page = (int)(offset);
    float alphaValue = offset - (int)offset;
    
    if (alphaValue < 0 && self.currentPageIndex == 0){
        [self.pageBgBack setImage:nil];
        [self.pageBgFront setAlpha:(1 + alphaValue)];
        return;
    }
    
    [self.pageBgFront setAlpha:1];
    [self.pageBgFront setImage:[self bgForPage:page]];
    [self.pageBgBack setAlpha:0];
    [self.pageBgBack setImage:[self bgForPage:page+1]];
    
    float backLayerAlpha = alphaValue;
    float frontLayerAlpha = (1 - alphaValue);
    
    [self.pageBgBack setAlpha:backLayerAlpha];
    [self.pageBgFront setAlpha:frontLayerAlpha];
}

- (UIImage *)bgForPage:(int)idx {
    if(idx >= _pages.count || idx < 0)
        return nil;
    
    return ((EAIntroPage *)_pages[idx]).bgImage;
}

#pragma mark - Custom setters

- (void)setPages:(NSArray *)pages {
    _pages = [pages copy];
    [self.scrollView removeFromSuperview];
    self.scrollView = nil;
    [self buildScrollViewWithFrame:self.frame];
}

- (void)setBgImage:(UIImage *)bgImage {
    _bgImage = bgImage;
    [self.bgImageView setImage:_bgImage];
}

- (void)setSwipeToExit:(bool)swipeToExit {
    if (swipeToExit != _swipeToExit) {
        CGFloat contentXIndex = self.scrollView.contentSize.width;
        if(swipeToExit) {
            [self appendCloseViewAtXIndex:&contentXIndex];
        } else {
            [self removeCloseViewAtXIndex:&contentXIndex];
        }
        self.scrollView.contentSize = CGSizeMake(contentXIndex, self.scrollView.frame.size.height);
    }
    _swipeToExit = swipeToExit;
    
}

- (void)setTitleView:(UIView *)titleView {
    [_titleView removeFromSuperview];
    _titleView = titleView;
    [_titleView setFrame:CGRectMake((self.frame.size.width-_titleView.frame.size.width)/2, self.titleViewY, _titleView.frame.size.width, _titleView.frame.size.height)];
    [self addSubview:_titleView];
    
}

- (void)setTitleViewY:(CGFloat)titleViewY {
    _titleViewY = titleViewY;
    [_titleView setFrame:CGRectMake((self.frame.size.width-_titleView.frame.size.width)/2, self.titleViewY, _titleView.frame.size.width, _titleView.frame.size.height)];
}

- (void)setPageControlY:(CGFloat)pageControlY {
    _pageControlY = pageControlY;
    [self.pageControl setFrame:CGRectMake(0, self.frame.size.height - pageControlY, self.frame.size.width, 20)];
}

- (void)setSkipButton:(UIButton *)skipButton {
    [_skipButton removeFromSuperview];
    _skipButton = skipButton;
    [_skipButton addTarget:self action:@selector(skipIntroduction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_skipButton];
}

#pragma mark - Actions

- (void)makePanelVisibleAtIndex:(NSInteger)panelIndex{
    [UIView animateWithDuration:0.3 animations:^{
        for (int idx = 0; idx < pageViews.count; idx++) {
            if (idx == panelIndex) {
                [pageViews[idx] setAlpha:1];
            }
            else {
                if(!self.hideOffscreenPages) {
                    [pageViews[idx] setAlpha:0];
                }
            }
        }
    }];
}

- (void)showPanelAtPageControl {
    LastPageIndex = self.pageControl.currentPage;
    self.currentPageIndex = self.pageControl.currentPage;
    
    [self makePanelVisibleAtIndex:(NSInteger)self.currentPageIndex];
    
    [self.scrollView setContentOffset:CGPointMake(self.currentPageIndex * 320, 0) animated:YES];
}

- (void)skipIntroduction {
    if ([(id)self.delegate respondsToSelector:@selector(introDidFinish)]) {
        [self.delegate introDidFinish];
    }
    
    [self hideWithFadeOutDuration:0.3];
}

- (void)hideWithFadeOutDuration:(CGFloat)duration {
    [UIView animateWithDuration:duration animations:^{
        self.alpha = 0;
    } completion:nil];
}

- (void)showInView:(UIView *)view animateDuration:(CGFloat)duration {
    self.alpha = 0;
    [self.scrollView setContentOffset:CGPointZero];
    [view addSubview:self];
    
    [UIView animateWithDuration:duration animations:^{
        self.alpha = 1;
    }];
}

@end
