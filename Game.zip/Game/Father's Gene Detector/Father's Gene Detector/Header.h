//
//  Header.h
//  QKInfoCardDemo
//
//  Created by KimJunhyuk  on 15/8/7.
//  Copyright (c) 2015年 Qiankai. All rights reserved.
//

#ifndef QKInfoCardDemo_Header_h
#define QKInfoCardDemo_Header_h
static int plus;


#endif
