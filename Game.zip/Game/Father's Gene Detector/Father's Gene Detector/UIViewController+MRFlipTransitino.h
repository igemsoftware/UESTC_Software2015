//
//  UIViewController+MRFlipTransitino.m
//


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "AnotherViewController1.h"
#import "optionview.h"


@interface UIViewController (MRFlipTransitino)

- (UIView *)viewForTransitionContext:(id <UIViewControllerContextTransitioning>)transitionContext;

@end
