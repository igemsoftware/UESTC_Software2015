//
//  AnotherViewController2.m
//  QKInfoCardDemo
//
//  Created by Bruce on 8/5/15.
//  Copyright (c) 2015 bruce. All rights reserved.
//



#import "AnotherViewController2.h"

#import "MRFlipTransition.h"
#import "CUSFlashLabel.h"
#import "AppDelegate.h"

@interface AnotherViewController2 ()

@end

@implementation AnotherViewController2

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    

     self.view.backgroundColor =  [UIColor colorWithPatternImage: [UIImage imageNamed:@"shadow.png"]];
    
    
    son1 = [[UIButton alloc] initWithFrame:CGRectMake(90,176,260,260)];
    [son1 addTarget:self action:@selector(bodytouch:) forControlEvents:UIControlEventTouchUpInside];
    [son1 setBackgroundImage:[UIImage imageNamed:@"son1_on"] forState:UIControlStateNormal];
    [self.view addSubview:son1];
    son1.alpha = 0.7;
        
    
    label = [[CUSFlashLabel alloc]initWithFrame:CGRectMake(110, 546, 300, 80)];
    [label setText:@"Click the body to"];
    [label setFont:[UIFont fontWithName:@"papyrus"  size:20]];
    [label setContentMode:UIViewContentModeTop];
    [label startAnimating];
    [self.view addSubview:label];
    
    label2 = [[CUSFlashLabel alloc]initWithFrame:CGRectMake(120, 576, 300, 80)];
    [label2 setText:@"check the gene"];
    [label2 setFont:[UIFont fontWithName:@"papyrus"  size:20]];
    [label2 setContentMode:UIViewContentModeTop];
    [label2 startAnimating];
    [self.view addSubview:label2];
    
    
    [AppDelegate storyBoradAutoLay:self.view];
}





- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [(MRFlipTransition *)self.transitioningDelegate updateContentSnapshot:self.view afterScreenUpdate:YES];
}

- (void)flyAway:(id)sender
{
    [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
}
- (void)bodytouch:(id)sender
{
  
    
    if(state == 0)
    {
        
        [[SoundManager sharedManager] playSound:@"flash.mp3" looping:NO];
        son1.frame=CGRectMake(90,176,260,260);
        label.frame=CGRectMake(110, 546, 300, 80);
        label2.frame=CGRectMake(120, 576, 300, 80);
        
    UIButton *dna1 = [[UIButton alloc] initWithFrame:CGRectMake(45, 45, 100, 40)];
    [dna1 setBackgroundImage:[UIImage imageNamed:@"2_on"] forState:UIControlStateNormal];
    
    UIButton *dna2 = [[UIButton alloc] initWithFrame:CGRectMake(45, 45, 100, 40)];
    [dna2 setBackgroundImage:[UIImage imageNamed:@"4_on"] forState:UIControlStateNormal];
    
    UIButton *dna3 = [[UIButton alloc] initWithFrame:CGRectMake(45, 45, 100, 40)];
    [dna3 setBackgroundImage:[UIImage imageNamed:@"3_on"] forState:UIControlStateNormal];
    
    UIButton *dna4 = [[UIButton alloc] initWithFrame:CGRectMake(45, 45, 100, 40)];
    [dna4 setBackgroundImage:[UIImage imageNamed:@"8_on"] forState:UIControlStateNormal];
    
    [self.view addSubview:dna1];
    [self.view addSubview:dna2];
    [self.view addSubview:dna3];
    [self.view addSubview:dna4];
    
    UIImageView *circle1 = [[UIImageView alloc] initWithFrame:CGRectMake(110,225,40,40)];
    [circle1 setImage:[UIImage imageNamed:@"circle1.png"]];
    [self.view addSubview:circle1];
    
    UIImageView *circle2 = [[UIImageView alloc] initWithFrame:CGRectMake(110,225,40,40)];
    [circle2 setImage:[UIImage imageNamed:@"circle1.png"]];
    [self.view addSubview:circle2];
    
    UIImageView *circle3 = [[UIImageView alloc] initWithFrame:CGRectMake(110,225,40,40)];
    [circle3 setImage:[UIImage imageNamed:@"circle1.png"]];
    [self.view addSubview:circle3];
    
    UIImageView *circle4 = [[UIImageView alloc] initWithFrame:CGRectMake(110,225,40,40)];
    [circle4 setImage:[UIImage imageNamed:@"circle1.png"]];
    [self.view addSubview:circle4];
    
    
    
    
    
    
    
    
    
    
    dna1.alpha = 0;
    dna1.frame = CGRectMake(155,280, 10,10);
    
    dna2.alpha = 0;
    dna2.frame = CGRectMake(90,215, 10,10);
    
    dna3.alpha = 0;
    dna3.frame = CGRectMake(200,390, 10,10);
    
    dna4.alpha = 0;
    dna4.frame = CGRectMake(195,260, 10,10);
    
    
    
    circle1.alpha = 0;
    circle1.frame = CGRectMake(155,280, 0,0);
    
    circle2.alpha = 0;
    circle2.frame = CGRectMake(90,215, 0,0);
    
    circle3.alpha = 0;
    circle3.frame = CGRectMake(200,390, 0,0);
    
    circle4.alpha = 0;
    circle4.frame = CGRectMake(195,260, 0,0);
    
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1];
    
    
    
        dna1.alpha = 1;
        dna1.frame = CGRectMake(40,320, 100, 40);
        dna2.alpha = 1;
        dna2.frame = CGRectMake(110,140, 100, 40);
        dna3.alpha = 1;
        dna3.frame = CGRectMake(180,460, 100, 40);
        dna4.alpha = 1;
        dna4.frame = CGRectMake(235,160, 100,40);
        
        
        
        circle1.alpha = 1;
        circle1.frame = CGRectMake(155,280, 40,40);
        
        circle2.alpha = 1;
        circle2.frame = CGRectMake(90,215, 40,40);
        
        circle3.alpha = 1;
        circle3.frame = CGRectMake(200,390, 40,40);
        
        circle4.alpha = 1;
        circle4.frame = CGRectMake(195,260, 40,40);
        
        [UIView commitAnimations];
        
        [AppDelegate storyBoradAutoLay:self.view];
        
        dna1.transform = CGAffineTransformRotate(dna1.transform, M_PI_4*3.7);
        dna2.transform = CGAffineTransformRotate(dna2.transform, M_PI_4*3.7);
        dna3.transform = CGAffineTransformRotate(dna3.transform, M_PI_4*3.7);
        dna4.transform = CGAffineTransformRotate(dna4.transform, M_PI_4*3.7);


        state++;
    }
    
    
}
///










//点击周围就退出
- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [[event allTouches] anyObject];
    CGPoint touchPoint = [touch locationInView:self.view];
    [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
    state--;
}

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [[event allTouches] anyObject];
    CGPoint touchPoint = [touch locationInView:self.view];
    [(MRFlipTransition *)self.transitioningDelegate dismissTo:MRFlipTransitionPresentingFromBottom completion:nil];
}


@end
