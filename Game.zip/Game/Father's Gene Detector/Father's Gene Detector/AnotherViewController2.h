//
//  AnotherViewController2.h
//  QKInfoCardDemo
//
//  Created by Bruce on 8/5/15.
//  Copyright (c) 2015 bruce. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CUSFlashLabel.h"
#import "SoundManager.h"

@interface AnotherViewController2 : UIViewController
{
    int state;
    int refresh;
    UIButton *son1;
    CUSFlashLabel *label;
    CUSFlashLabel *label2;
}
@end
