//
//  AppDelegate.h
//  Father's Gene Detector
//
//  Created by Bruce on 9/11/15.
//  Copyright (c) 2015 Bruce. All rights reserved.
//

#import <UIKit/UIKit.h>
@class SoundManagerExampleViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    int* plus;
}

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, retain) IBOutlet SoundManagerExampleViewController *viewController;
@property (nonatomic) int *plus;

@property float autoSizeScaleX;
@property float autoSizeScaleY;

+ (void)storyBoradAutoLay:(UIView *)allView;

@end

